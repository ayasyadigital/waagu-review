import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { LocationStrategy } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { } from '@types/googlemaps';
import { AgmCoreModule } from 'angular2-google-maps/core';
import { ImageCropperComponent } from 'ng2-img-cropper';
import {CalendarModule,DropdownModule} from 'primeng/primeng';

import { routes } from './app.router';


import { UserLoginService, CognitoUtil, UserParametersService, UserCognitoService,UserRegistrationService } from "./services/cognito.service";
import { AwsUtil } from "./services/aws.service";
import { DdbService } from "./services/ddb.service";
import { ValidationService } from './services/validation.service';
import { LoaderService } from './services/loader.service';
import { AppComponent } from './app.component';
import { LoginComponent } from './component/login/login.component';

import { SignupComponent } from './component/signup/signup.component';
import { ControlMessagesComponent } from './component/control-messages/control-messages.component';

import { MatchHeightDirective } from './directives/match-height.directive';
import { ConfirmRegistrationComponent } from './component/confirm-registration/confirm-registration.component';
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { DealsComponent } from './component/deals/deals.component';
import { ForgotComponent } from './component/forgot/forgot.component';
import { ForgotnextComponent } from './component/forgotnext/forgotnext.component';
import { UsersComponent } from './component/users/users.component';
import {NgPipesModule} from 'ngx-pipes';
import { CategoryPipe } from './pipe/category.pipe';
import { OrderByPipe } from './pipe/order-by.pipe';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MatchHeightDirective,
    SignupComponent,
    ControlMessagesComponent,
    ImageCropperComponent,
    ConfirmRegistrationComponent,
    DashboardComponent,
    DealsComponent,
    ForgotComponent,
    ForgotnextComponent,
    UsersComponent,
    CategoryPipe,
    OrderByPipe
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    routes,
    RouterModule,
    AgmCoreModule.forRoot({
      apiKey: "AIzaSyCAJO9x-cvew7SvPKaVe6pCUwfWQJcJL4o",
      libraries: ["places"]
    }),
    FormsModule,
    ReactiveFormsModule,
    CalendarModule,
    DropdownModule,
    NgPipesModule
  ],
 providers: [
    LoaderService,
    ValidationService,
    CognitoUtil,
    AwsUtil,
    DdbService,
    UserLoginService,
    UserParametersService,
    UserCognitoService,
    UserRegistrationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
