import { Injectable, NgZone } from '@angular/core';
import { environment } from "../../environments/environment";

import { Deal, User, Counts, AppData, DealHistory } from '../models/models';

import { CognitoCallback, DataCallback, Callback, LocationCallback, DataCallbackStatus, DataCallbackDeal } from '../interfaces/interfaces';

import { CognitoUtil, UserLoginService, UserParametersService, UserCognitoService } from "../services/cognito.service";
import { LoaderService } from '../services/loader.service';
import { AgmCoreModule, MapsAPILoader } from 'angular2-google-maps/core';
import { Buffer } from 'buffer';
import * as geolib from 'geolib';
import { UUID } from 'angular2-uuid';
import * as moment from 'moment';
import * as momenttz from 'moment-timezone';

export let user_Role: number;
export let user_Email: string;
export let params: {};
declare var AWS: any;
declare var AWSCognito: any;
@Injectable()
export class DdbService implements CognitoCallback, DataCallback, LocationCallback, DataCallbackStatus, DataCallbackDeal {

  constructor(
    public ngZone: NgZone,
    public mapsAPILoader: MapsAPILoader,
    public loaderService: LoaderService, public userParametersService: UserParametersService, public usercognitoService: UserCognitoService,
    public cognitoUtil: CognitoUtil
  ) {
    user_Role = parseInt(localStorage.getItem("userRole"));
    user_Email = localStorage.getItem("emailId");
  }
  getAWS() {
    return AWS;
  }
  gettest() {
    this.loaderService.display(true);
    params = {
      TableName: 'LoginTrail',
      IndexName: 'activityDate-timestamp-index',
      ScanIndexForward: false
    };
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.scan(params, (error, result) => {
      //console.log(error);
      //console.log(result);
      this.loaderService.display(false);
    });
  }
  /* Manage Dashboard */
  getDashboardCounts(mapArray: Counts) {

    user_Role = parseInt(localStorage.getItem("userRole"));
    user_Email = localStorage.getItem("emailId");
    this.loaderService.display(true);

    params = {
      TableName: environment.ddbUserTableName,
      ProjectionExpression: "userRole"
    };
    if (user_Role == 0) {
      params = {
        TableName: environment.ddbUserTableName,
        FilterExpression: "#EmailId = :eid",
        ProjectionExpression: "userRole",
        ExpressionAttributeNames: {
          "#EmailId": "EmailId"
        },
        ExpressionAttributeValues: {
          ":eid": user_Email
        }
      };
    }
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.scan(params, (error, result) => {
      if (error) {
        console.error("DynamoDBService: Unable to query the table. Error JSON:", JSON.stringify(error, null, 2));
        this.loaderService.display(false);
      } else {
        mapArray.usercount = result.Count;
        mapArray.inactive_usercount = 0;
      }
    });
    //Deals Total Count

    const timestamp = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
    params = {
      TableName: environment.ddbTableName,
      ProjectionExpression: "Stuff"
    };
    if (user_Role == 0) {
      params = {
        TableName: environment.ddbTableName,
        FilterExpression: "#EmailId = :eid",
        ProjectionExpression: "Stuff",
        ExpressionAttributeNames: {
          "#EmailId": "EmailId"
        },
        ExpressionAttributeValues: {
          ":eid": user_Email
        },
      };
    }
    docClient.scan(params, (error, result) => {
      if (error) {
        console.error("DynamoDBService: Unable to query the table. Error JSON:", JSON.stringify(error, null, 2));
        this.loaderService.display(false);
      } else {
        mapArray.totalavailableDealsCount = result.Count;
        var diningCount = 0;
        var clothingCount = 0;
        var electronicsCount = 0;
        var groceriesCount = 0;
        var otherstuffCount = 0;
        result.Items.forEach(function (item) {
          if (item.Stuff == 'Dining') {
            diningCount = diningCount + 1;
          }
          else if (item.Stuff == 'Clothing') {
            clothingCount = clothingCount + 1;
          }
          else if (item.Stuff == 'Electronics') {
            electronicsCount = electronicsCount + 1;
          } else if (item.Stuff == 'Groceries') {
            groceriesCount = groceriesCount + 1;
          } else if (item.Stuff == 'Other Stuff') {
            otherstuffCount = otherstuffCount + 1;
          }

        });

        mapArray.totaldiningCount = diningCount;
        mapArray.totalclothingCount = clothingCount;
        mapArray.totalelectronicsCount = electronicsCount;
        mapArray.totalgroceriesCount = groceriesCount;
        mapArray.totalotherstuffCount = otherstuffCount;
        this.loaderService.display(false);
        //Deal disable Count
        params = {
          TableName: environment.ddbTableName,
          FilterExpression: "#DealStatus = :dp",
          ExpressionAttributeNames: {
            "#DealStatus": "DealStatus"
          },
          ExpressionAttributeValues: {
            ":dp": "false"
          },
        };
        if (user_Role == 0) {
          params = {
            TableName: environment.ddbTableName,
            ProjectionExpression: "Stuff",
            FilterExpression: "#DealStatus = :dp and #EmailId = :eid",
            ExpressionAttributeNames: {
              "#DealStatus": "DealStatus",
              "#EmailId": "EmailId"
            },
            ExpressionAttributeValues: {
              ":dp": "false",
              ":eid": user_Email
            }
          };
        }
        docClient.scan(params, (error1, result1) => {
          if (error1) {
            console.error("DynamoDBService: Unable to query the table. Error JSON:", JSON.stringify(error1, null, 2));
            this.loaderService.display(false);
          } else {
            mapArray.disable_availableDealsCount = result1.Count;
            var disable_diningCount = 0;
            var disable_clothingCount = 0;
            var disable_electronicsCount = 0;
            var disable_groceriesCount = 0;
            var disable_otherstuffCount = 0;
            result1.Items.forEach(function (item1) {
              if (item1.Stuff == 'Dining') {
                disable_diningCount = disable_diningCount + 1;
              }
              else if (item1.Stuff == 'Clothing') {
                disable_clothingCount = disable_clothingCount + 1;
              }
              else if (item1.Stuff == 'Electronics') {
                disable_electronicsCount = disable_electronicsCount + 1;
              } else if (item1.Stuff == 'Groceries') {
                disable_groceriesCount = disable_groceriesCount + 1;
              } else if (item1.Stuff == 'Other Stuff') {
                disable_otherstuffCount = disable_otherstuffCount + 1;
              }
            });
            mapArray.disable_diningCount = disable_diningCount;
            mapArray.disable_clothingCount = disable_clothingCount;
            mapArray.disable_electronicsCount = disable_electronicsCount;
            mapArray.disable_groceriesCount = disable_groceriesCount;
            mapArray.disable_otherstuffCount = disable_otherstuffCount;
            //Deals INactive Count
            params = {
              TableName: environment.ddbTableName,
              FilterExpression: "#DealStatus = :dp and #Reschedule =:res and #FinishDtp< :fnish",
              ProjectionExpression: "Stuff",
              ExpressionAttributeNames: {
                "#DealStatus": "DealStatus",
                "#Reschedule": "Reschedule",
                "#FinishDtp": "FinishDtp"
              },
              ExpressionAttributeValues: {
                ":dp": "true",
                ":res": "No Repeat",
                ":fnish": timestamp
              },
            };
            if (user_Role == 0) {
              params = {
                TableName: environment.ddbTableName,
                FilterExpression: "#EmailId = :eid and #DealStatus = :dp and #Reschedule =:res and #FinishDtp< :fnish",
                ProjectionExpression: "Stuff",
                ExpressionAttributeNames: {
                  "#EmailId": "EmailId",
                  "#DealStatus": "DealStatus",
                  "#Reschedule": "Reschedule",
                  "#FinishDtp": "FinishDtp"
                },
                ExpressionAttributeValues: {
                  ":eid": user_Email,
                  ":dp": "true",
                  ":res": "No Repeat",
                  ":fnish": timestamp
                },
              };
            }
            docClient.scan(params, (error2, result2) => {
              if (error2) {
                console.error("DynamoDBService: Unable to query the table. Error JSON:", JSON.stringify(error2, null, 2));
                this.loaderService.display(false);
              } else {
                mapArray.inactive_availableDealsCount = result2.Count;
                var inactive_diningCount = 0;
                var inactive_clothingCount = 0;
                var inactive_electronicsCount = 0;
                var inactive_groceriesCount = 0;
                var inactive_otherstuffCount = 0;
                result2.Items.forEach(function (item2) {
                  if (item2.Stuff == 'Dining') {
                    inactive_diningCount = inactive_diningCount + 1;
                  }
                  else if (item2.Stuff == 'Clothing') {
                    inactive_clothingCount = inactive_clothingCount + 1;
                  }
                  else if (item2.Stuff == 'Electronics') {
                    inactive_electronicsCount = inactive_electronicsCount + 1;
                  } else if (item2.Stuff == 'Groceries') {
                    inactive_groceriesCount = inactive_groceriesCount + 1;
                  } else if (item2.Stuff == 'Other Stuff') {
                    inactive_otherstuffCount = inactive_otherstuffCount + 1;
                  }
                });
                mapArray.inactive_diningCount = inactive_diningCount;
                mapArray.inactive_clothingCount = inactive_clothingCount;
                mapArray.inactive_electronicsCount = inactive_electronicsCount;
                mapArray.inactive_groceriesCount = inactive_groceriesCount;
                mapArray.inactive_otherstuffCount = inactive_otherstuffCount;

                mapArray.availableDealsCount = mapArray.totalavailableDealsCount - (mapArray.disable_availableDealsCount + mapArray.inactive_availableDealsCount);
                mapArray.diningCount = mapArray.totaldiningCount - (mapArray.disable_diningCount + mapArray.inactive_diningCount);
                mapArray.clothingCount = mapArray.totalclothingCount - (mapArray.disable_clothingCount + mapArray.inactive_clothingCount);
                mapArray.electronicsCount = mapArray.totalelectronicsCount - (mapArray.disable_electronicsCount + mapArray.inactive_electronicsCount);
                mapArray.groceriesCount = mapArray.totalgroceriesCount - (mapArray.disable_groceriesCount + mapArray.inactive_groceriesCount);
                mapArray.otherstuffCount = mapArray.totalotherstuffCount - (mapArray.disable_otherstuffCount + mapArray.inactive_otherstuffCount);
                this.loaderService.display(false);
              }
            });
          }
        });
      }
    });
  }

  /*Manage User */
  userSignup(data: any, datacall: DataCallback) {
    this.loaderService.display(true);
    const timestamp = this.nowUtctime();
    data.EmailId = data.EmailId.toLowerCase();
    const uid = UUID.UUID();
    //console.log(data.EmailId);
    data.FeatureImage = 'https://' + environment.s3bucketName + '.s3.amazonaws.com/' + data.EmailId + "/features/" + uid + ".jpg"
    //console.log(data.EmailId);
    var AWSService = this.getAWS();
    const dynamoDb = new AWSService.DynamoDB.DocumentClient({
      region: CognitoUtil._REGION,
      accessKeyId: environment.accessKeyId,
      secretAccessKey: environment.secretAccessKey
    });
    var s3Bucket = new AWSService.S3({
      region: CognitoUtil._REGION,
      accessKeyId: environment.accessKeyId,
      secretAccessKey: environment.secretAccessKey
    });
    s3Bucket.config.region = CognitoUtil._REGION;
    s3Bucket.createBucket(function () {
      var buffer = new Buffer(data.imgData.replace(/^data:image\/\w+;base64,/, ""), 'base64');
      var par = { Bucket: environment.s3bucketName + '/' + data.EmailId + "/features", Key: uid + ".jpg", Body: buffer, ContentEncoding: 'base64', ContentType: 'image/jpg' };
      s3Bucket.putObject(par, function (err, data) {
        if (err) {
          datacall.dataCallback(err, null);
        }
      });
    });
    s3Bucket.createBucket(function () {
      var params = { Bucket: environment.s3bucketName + '/' + data.EmailId + '/deals', Key: data.EmailId + '.json', Body: JSON.stringify(data) };
      s3Bucket.putObject(params, function (err, data) {
        if (err) {
          datacall.dataCallback(err, null);
        }
      });

    });
    const params = {
      TableName: environment.ddbUserTableName,
      Item: {
        CompanyName: data.CompanyName,
        EmailId: data.EmailId,
        Password: data.Password,
        CompanyLocation: {
          Longitude: parseFloat(data.Longitude),
          Latitude: parseFloat(data.Latitude),
          Address: data.Address,
        },
        Stuff: data.Stuff,
        FeatureImage: data.FeatureImage,
        userStatus: "true",
        CratedDtp: timestamp,
        ModifiedDtp: timestamp,
        userRole: 0
      }
    };
    dynamoDb.put(params, (error, result) => {
      if (error) {
        datacall.dataCallback(error, null);
      } else {
        localStorage.setItem("userPassword", data.Password);
        datacall.dataCallback(null, result);
      }
    });
  };

  getUserEntries(mapArray: Array<User>) {
    user_Role = parseInt(localStorage.getItem("userRole"));
    user_Email = localStorage.getItem("emailId");
    this.loaderService.display(true);
    params = {
      TableName: environment.ddbUserTableName,
      ProjectionExpression: "CompanyLocation,userStatus,EmailId,FeatureImage,Stuff,CompanyName,CratedDtp,userRole"
      // FilterExpression: "#userRole = :urole",
      // ExpressionAttributeNames: {
      //   "#userRole": "userRole"
      // },
      // ExpressionAttributeValues: {
      //   ":urole": 0
      // }
    };
    if (user_Role == 0) {
      params = {
        TableName: environment.ddbUserTableName,
        ProjectionExpression: "CompanyLocation,userStatus,EmailId,FeatureImage,Stuff,CompanyName,CratedDtp,userRole",
        FilterExpression: "#EmailId = :eid",
        ExpressionAttributeNames: {
          "#EmailId": "EmailId"
        },
        ExpressionAttributeValues: {
          ":eid": user_Email
        }
      };
    }
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.scan(params, (error, result) => {
      if (error) {
        this.loaderService.display(false);
      } else {
        result.Items.forEach(function (item) {
          mapArray.push({
            Address: item.CompanyLocation.Address,
            Longitude: parseFloat(item.CompanyLocation.Longitude),
            Latitude: parseFloat(item.CompanyLocation.Latitude),
            userStatus: item.userStatus,
            EmailId: item.EmailId,
            FeatureImage: item.FeatureImage + "?" + new Date(),
            Stuff: item.Stuff,
            View: false,
            CompanyName: item.CompanyName,
            CratedDtp: moment.utc(item.CratedDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD HH:mm:ss'),
            userRole: item.userRole
          });
        });
        this.loaderService.display(false);
      }
    });
  }

  getUserActiveEntries(callback: DataCallbackStatus) {
    user_Email = localStorage.getItem("emailId");
    this.loaderService.display(true);
    params = {
      TableName: environment.ddbUserTableName,
      FilterExpression: "#EmailId = :eid",
      ExpressionAttributeNames: {
        "#EmailId": "EmailId"
      },
      ExpressionAttributeValues: {
        ":eid": user_Email
      }
    };
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.scan(params, (error, result) => {
      if (error) {
        callback.dataCallbackStatus("", "")
        this.loaderService.display(false);
      } else {
        // status = result.Items[0].userStatus;
        callback.dataCallbackStatus(null, result.Items[0].userStatus);
        this.loaderService.display(false);
      }
    });
  }
  updateUserStatus(EmailId: string, Status: string) {
    this.loaderService.display(true);
    const params = {
      TableName: environment.ddbUserTableName,
      Key: {
        'EmailId': EmailId,
      },
      UpdateExpression: 'SET userStatus = :userStatus',
      ExpressionAttributeValues: {
        ':userStatus': Status
      },
      ReturnValues: 'UPDATED_NEW',
    };
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.update(params, (error, result) => {
      if (error) {
        this.loaderService.display(false);
      } else {
        if (Status == 'true') {
          this.usercognitoService.enableUser(EmailId, this);
          this.loaderService.display(false);
        } else {
          this.usercognitoService.disableUser(EmailId, this);
          this.usercognitoService.userGlobalSignOut(EmailId, this);
          this.loaderService.display(false);
        }
      }
    });
  }

  updateUserPassword(EmailId: string, Password: string, datacall: DataCallback) {
    this.loaderService.display(true);
    var AWSService = this.getAWS();
    const docClient = new AWSService.DynamoDB.DocumentClient({
      region: CognitoUtil._REGION,
      accessKeyId: environment.accessKeyId,
      secretAccessKey: environment.secretAccessKey
    });
    const params = {
      TableName: environment.ddbUserTableName,
      Key: {
        'EmailId': EmailId,
      },
      UpdateExpression: 'SET Password = :Password',
      ExpressionAttributeValues: {
        ':Password': Password
      },
      ReturnValues: 'UPDATED_NEW',
    };
    docClient.update(params, (error, result) => {
      if (error) {
        datacall.dataCallback(error, null);
        this.loaderService.display(false);
      } else {
        datacall.dataCallback(null, result);
        this.loaderService.display(false);
      }
    });
  }

  updateAdminStatus(EmailId: string, Status: number) {
    this.loaderService.display(true);
    const params = {
      TableName: environment.ddbUserTableName,
      Key: {
        'EmailId': EmailId,
      },
      UpdateExpression: 'SET userRole = :userRole',
      ExpressionAttributeValues: {
        ':userRole': Status
      },
      ReturnValues: 'UPDATED_NEW',
    };
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.update(params, (error, result) => {
      if (error) {
        this.loaderService.display(false);
      } else {
        this.usercognitoService.updateGorupUser(EmailId,Status,this);
        this.loaderService.display(false);
      }
    });
  }

  getUserDetails(EmailId: string, datacall: DataCallback) {
    this.loaderService.display(true);
    params = {
      TableName: environment.ddbUserTableName,
      FilterExpression: "#EmailId = :eid",
      ProjectionExpression: "EmailId,userRole",
      ExpressionAttributeNames: {
        "#EmailId": "EmailId"
      },
      ExpressionAttributeValues: {
        ":eid": EmailId
      },

    };

    var docClient = new AWS.DynamoDB.DocumentClient();

    docClient.scan(params, (error, result) => {
      if (error) {
        console.error("DynamoDBService: Unable to query the table. Error JSON:", JSON.stringify(error, null, 2));
        datacall.dataCallback(error, null);
      } else {
        localStorage.setItem("userRole", result.Items[0].userRole.toString());
        localStorage.setItem("emailId", result.Items[0].EmailId);
        datacall.dataCallback(null, result);
      }
    });

  }

  updateUserDetails(CompanyName: string, EmailId: string, Shop: string, editPassword: boolean, oldPassword: string, newPassword: string, uploadImg: boolean, imgData: string) {
    user_Role = parseInt(localStorage.getItem("userRole"));
    this.loaderService.display(true);
    if (editPassword == true) {
      params = {
        TableName: environment.ddbUserTableName,
        Key: {
          'EmailId': EmailId,
        },
        UpdateExpression: 'SET CompanyName = :CompanyName , Stuff = :stuf,Password = :pwd',
        ExpressionAttributeValues: {
          ':CompanyName': CompanyName,
          ':stuf': Shop,
          ':pwd': newPassword
        },
        ReturnValues: 'ALL_NEW',
      };
    } else {
      params = {
        TableName: environment.ddbUserTableName,
        Key: {
          'EmailId': EmailId,
        },
        UpdateExpression: 'SET CompanyName = :CompanyName , Stuff = :stuf',
        ExpressionAttributeValues: {
          ':CompanyName': CompanyName,
          ':stuf': Shop
        },
        ReturnValues: 'ALL_NEW',
      };
    }

    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.update(params, (error, result) => {
      if (error) {
        this.loaderService.display(false);
      } else {
        var featureimg = result.Attributes.FeatureImage;
        var eid = result.Attributes.EmailId;
        var keyval = featureimg.replace("https://" + environment.s3bucketName + ".s3.amazonaws.com/" + eid + "/features/", "");
        if (uploadImg == true) {
          var AWSService = this.getAWS();
          var s3Bucket = new AWSService.S3({
            region: CognitoUtil._REGION,
            accessKeyId: environment.accessKeyId,
            secretAccessKey: environment.secretAccessKey
          });
          s3Bucket.config.region = CognitoUtil._REGION;
          s3Bucket.createBucket(function () {
            var buffer = new Buffer(imgData.replace(/^data:image\/\w+;base64,/, ""), 'base64');
            var par = { Bucket: environment.s3bucketName + '/' + eid + "/features", Key: keyval, Body: buffer, ContentEncoding: 'base64', ContentType: 'image/jpg' };
            s3Bucket.putObject(par, function (err, data) {
              if (err) {

              } else {

              }
            });
          });
        }
        if (user_Role == 0) {
          this.userParametersService.updateParameters(CompanyName, this);
          if (editPassword == true) {
            this.userParametersService.changePassword(oldPassword, newPassword, this);
          }
        } else {
          this.usercognitoService.updateParameters(CompanyName, EmailId, this);
        }
        const params2 = {
          TableName: environment.ddbLogTableName,
          FilterExpression: "#EmailId = :eid",
          ExpressionAttributeNames: {
            "#EmailId": "EmailId"
          },
          ExpressionAttributeValues: {
            ":eid": EmailId
          }
        };
        docClient.scan(params2, (error1, result1) => {
          if (error1) {
            this.loaderService.display(false);
          } else {
            result1.Items.forEach(function (item) {
              const paramsupdate = {
                TableName: environment.ddbLogTableName,
                Key: {
                  'DealHistoryId': item.DealHistoryId,
                },
                UpdateExpression: 'SET CompanyName = :CompanyName , Stuff = :stuf',
                ExpressionAttributeValues: {
                  ':CompanyName': CompanyName,
                  ':stuf': Shop
                },
                ReturnValues: 'UPDATED_NEW',
              };
              docClient.update(paramsupdate, (error2, result2) => {
                if (error2) {
                  console.error("2:", JSON.stringify(error2, null, 2));
                }
              });
            });
          }
        });
        const params3 = {
          TableName: environment.ddbTableName,
          FilterExpression: "#EmailId = :eid",
          ExpressionAttributeNames: {
            "#EmailId": "EmailId"
          },
          ExpressionAttributeValues: {
            ":eid": EmailId
          }
        };
        docClient.scan(params3, (error1, result1) => {
          if (error1) {
            this.loaderService.display(false);
          } else {
            result1.Items.forEach(function (item) {
              const paramsupdate = {
                TableName: environment.ddbTableName,
                Key: {
                  'DealId': item.DealId,
                },
                UpdateExpression: 'SET Stuff = :stuf',
                ExpressionAttributeValues: {
                  ':stuf': Shop
                },
                ReturnValues: 'UPDATED_NEW',
              };
              docClient.update(paramsupdate, (error2, result2) => {
                if (error2) {
                  console.error("2:", JSON.stringify(error2, null, 2));
                }
                const paramsdeal = {
                  TableName: environment.ddbSnsCronTableName,
                  FilterExpression: "#DealId= :dealid",
                  ExpressionAttributeNames: {
                    "#DealId": "DealId"
                  },
                  ExpressionAttributeValues: {
                    ":dealid": item.DealId
                  }
                };
                docClient.scan(paramsdeal, (error6, result6) => {
                  if (error6) {
                   
                  }
                  if (result6.Items.length > 0) {
                    result6.Items.forEach(function (item4) {
                      const paramsdeal = {
                        TableName: environment.ddbSnsCronTableName,
                        Key: {
                          'CronId': item4.CronId,
                        },
                        UpdateExpression: 'set Stuff = :stuf',
                        ExpressionAttributeValues: {
                          ':stuf': Shop
                        },
                        ReturnValues: 'UPDATED_NEW',
                      };
                      docClient.update(paramsdeal, (error7, result7) => {
                        if (error7) {
                         
                        }
                       
                      });
                    });
                  } else {
                    
                  }
                });

              });
            });
          }
        });
      }
    });
  }

  updateUserMapDetails(EmailId: string, Markers: JSON) {
    user_Role = parseInt(localStorage.getItem("userRole"));
    this.loaderService.display(true);

    params = {
      TableName: environment.ddbUserTableName,
      Key: {
        'EmailId': EmailId,
      },
      UpdateExpression: 'SET CompanyLocation.Latitude = :lat , CompanyLocation.Longitude = :lng, CompanyLocation.Address = :add',
      ExpressionAttributeValues: {
        ':lat': Markers[0].lat,
        ':lng': Markers[0].lng,
        ':add': Markers[0].address
      },
      ReturnValues: 'ALL_NEW',
    };
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.update(params, (error, result) => {
      if (error) {
        this.loaderService.display(false);
      } else {
        const params2 = {
          TableName: environment.ddbLogTableName,
          FilterExpression: "#EmailId = :eid",
          ExpressionAttributeNames: {
            "#EmailId": "EmailId"
          },
          ExpressionAttributeValues: {
            ":eid": EmailId
          }
        };
        docClient.scan(params2, (error1, result1) => {
          if (error1) {
            this.loaderService.display(false);
          } else {
            result1.Items.forEach(function (item) {
              const paramsupdate = {
                TableName: environment.ddbLogTableName,
                Key: {
                  'DealHistoryId': item.DealHistoryId,
                },
                UpdateExpression: 'SET Latitude = :lat , Longitude = :lng',
                ExpressionAttributeValues: {
                  ':lat': Markers[0].lat,
                  ':lng': Markers[0].lng
                },
                ReturnValues: 'UPDATED_NEW',
              };
              docClient.update(paramsupdate, (error2, result2) => {
                if (error2) {
                  console.error("2:", JSON.stringify(error2, null, 2));
                }
                const paramsdeal = {
                  TableName: environment.ddbSnsCronTableName,
                  FilterExpression: "#DealHistoryId= :dealid",
                  ExpressionAttributeNames: {
                    "#DealHistoryId": "DealHistoryId"
                  },
                  ExpressionAttributeValues: {
                    ":dealid": item.DealHistoryId
                  }
                };
                docClient.scan(paramsdeal, (error6, result6) => {
                  if (error6) {
                   
                  }
                  if (result6.Items.length > 0) {
                    result6.Items.forEach(function (item4) {
                      const paramsdeal = {
                        TableName: environment.ddbSnsCronTableName,
                        Key: {
                          'CronId': item4.CronId,
                        },
                        UpdateExpression: 'set  Latitude = :lat , Longitude = :lng',
                        ExpressionAttributeValues: {
                          ':lat': Markers[0].lat,
                          ':lng': Markers[0].lng
                        },
                        ReturnValues: 'UPDATED_NEW',
                      };
                      docClient.update(paramsdeal, (error7, result7) => {
                        if (error7) {
                         
                        }
                       
                      });
                    });
                  } else {
                    
                  }
                });

              });
            });
            this.loaderService.display(false);
          }
        });
      }
    });
  }
  /*Manage Deals */
  getDealEntries1(mapArray: Array<Deal>, EmailId = null) {
    this.loaderService.display(true);
    let userlist: any;
    user_Role = parseInt(localStorage.getItem("userRole"));
    user_Email = EmailId != null ? EmailId : localStorage.getItem("emailId");
    const timestamp = this.nowUtctime();
    if (user_Role == 0 || EmailId != null) {
      params = {
        TableName: environment.ddbTableName,
        FilterExpression: "#EmailId = :eid",
        ExpressionAttributeNames: {
          "#EmailId": "EmailId"
        },
        ExpressionAttributeValues: {
          ":eid": user_Email
        }
      };
      var docClient = new AWS.DynamoDB.DocumentClient();
      docClient.scan(params, (error, result) => {
        if (error) {
          console.error("DynamoDBService: Unable to query the table. Error JSON:", JSON.stringify(error, null, 2));
          this.loaderService.display(false);
        } else {
          const params1 = {
            TableName: environment.ddbLogTableName,
            FilterExpression: "#EmailId=:EmailId AND (#StartDtp<= :sdtp)",
            ExpressionAttributeNames: {
              "#EmailId": "EmailId",
              "#StartDtp": "StartDtp"
            },
            ExpressionAttributeValues: {
              ":EmailId": user_Email,
              ":sdtp": timestamp
            }
          };
          docClient.scan(params1, (error1, result1) => {
            var isStatus = 0;
            if (error1) {
              console.error("DynamoDBService: Unable to query the table. Error JSON:", JSON.stringify(error1, null, 2));
              this.loaderService.display(false);
            } else {
              result.Items.forEach(function (item) {
                var dealList = new Array<DealHistory>();
                var lastdate = null;
                result1.Items.forEach(function (item1) {
                  if (item.DealId == item1.DealId) {
                    dealList.push({
                      DealHistoryId: item1.DealHistoryId,
                      FinishDtp: item1.FinishDtp != 'null' ? moment.utc(item1.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD HH:mm:ss') : 'null',
                      StartDtp: moment.utc(item1.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD HH:mm:ss'),
                      UseCount: item1.UseCount
                    })
                  }
                });
                if (item.DealStatus == 'false') {
                  isStatus = 3;//disable
                }
                else if (item.FinishDtp == 'null') {
                  isStatus = 2;//active
                }
                else if (item.Reschedule == 'No Repeat') {
                  if (new Date() > moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().toDate()) {
                    isStatus = 1;//inactive
                  }
                  else if (dealList.length > 0) {
                    if (item.MaxCount == dealList[0].UseCount && item.MaxCount != -1) {
                      isStatus = 1;//inactive
                    } else {
                      isStatus = 2;//active
                    }
                  } else {
                    isStatus = 2;//active
                  }
                }
                else {
                  isStatus = 2;//active
                }

                mapArray.push({
                  CratedDtp: new Date(item.StartDtp),
                  DealId: item.DealId,
                  DealStatus: item.DealStatus,
                  Description: item.Description,
                  EmailId: item.EmailId,
                  FeatureImage: item.FeatureImage + "?" + new Date(),
                  FinishDtp: item.FinishDtp != null ? moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD') : null,
                  FinishDtpTime: item.FinishDtp != null ? moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss') : null,
                  Latitude: item.Latitude,
                  Longitude: item.Longitude,
                  MaxCount: item.MaxCount,
                  ModifiedDtp: item.ModifiedDtp,
                  RepeatFinishDtp: item.RepeatFinishDtp != null ? moment.utc(item.RepeatFinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD') : null,
                  RepeatFinishDtpTime: item.RepeatFinishDtp != null ? moment.utc(item.RepeatFinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss') : null,
                  RepeatStartDtp: moment.utc(item.RepeatStartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD'),
                  RepeatStartDtpTime: moment.utc(item.RepeatStartDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss'),
                  Reschedule: item.Reschedule,
                  StartDtp: moment.utc(item.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD'),
                  StartDtpTime: moment.utc(item.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss'),
                  Stuff: item.Stuff,
                  Title: item.Title,
                  View: false,
                  DealHistoryList: dealList,
                  IsStatus: isStatus
                });
              });
            }
          });

          this.loaderService.display(false);
        }
      });
    } else {
      params = {
        TableName: environment.ddbUserTableName,
        ProjectionExpression: "EmailId",
        FilterExpression: "#userRole = :urole",
        ExpressionAttributeNames: {
          "#userRole": "userRole"
        },
        ExpressionAttributeValues: {
          ":urole": 0
        }
      };
      var docClient = new AWS.DynamoDB.DocumentClient();

      docClient.scan(params, (error0, result0) => {
        if (error0) {
          console.error("DynamoDBService: Unable to query the table. Error JSON:", JSON.stringify(error0, null, 2));
          this.loaderService.display(false);
        }
        else {
          result0.Items.forEach(function (uitem) {
            params = {
              TableName: environment.ddbTableName,
              FilterExpression: "#EmailId = :eid",
              ExpressionAttributeNames: {
                "#EmailId": "EmailId"
              },
              ExpressionAttributeValues: {
                ":eid": uitem.EmailId
              }
            };

            docClient.scan(params, (error, result) => {
              if (error) {
                console.error("DynamoDBService: Unable to query the table. Error JSON:", JSON.stringify(error, null, 2));
                this.loaderService.display(false);
              } else {
                const params1 = {
                  TableName: environment.ddbLogTableName,
                  FilterExpression: "#EmailId=:EmailId AND (#StartDtp<= :sdtp)",
                  ExpressionAttributeNames: {
                    "#EmailId": "EmailId",
                    "#StartDtp": "StartDtp"
                  },
                  ExpressionAttributeValues: {
                    ":EmailId": uitem.EmailId,
                    ":sdtp": timestamp
                  }
                };
                docClient.scan(params1, (error1, result1) => {
                  var isStatus = 0;
                  if (error1) {
                    console.error("DynamoDBService: Unable to query the table. Error JSON:", JSON.stringify(error1, null, 2));
                    this.loaderService.display(false);
                  } else {
                    result.Items.forEach(function (item) {
                      var dealList = new Array<DealHistory>();
                      var lastdate = null;
                      result1.Items.forEach(function (item1) {
                        if (item.DealId == item1.DealId) {
                          dealList.push({
                            DealHistoryId: item1.DealHistoryId,
                            FinishDtp: item1.FinishDtp != 'null' ? moment.utc(item1.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD HH:mm:ss') : 'null',
                            StartDtp: moment.utc(item1.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD HH:mm:ss'),
                            UseCount: item1.UseCount
                          })
                        }
                      });
                      if (item.DealStatus == 'false') {
                        isStatus = 3;//disable
                      }
                      else if (item.FinishDtp == 'null') {
                        isStatus = 2;//active
                      }
                      else if (item.Reschedule == 'No Repeat') {
                        if (new Date() > moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().toDate()) {
                          isStatus = 1;//inactive
                        }
                        else if (dealList.length > 0) {
                          if (item.MaxCount == dealList[0].UseCount && item.MaxCount != -1) {
                            isStatus = 1;//inactive
                          } else {
                            isStatus = 2;//active
                          }
                        } else {
                          isStatus = 2;//active
                        }
                      }
                      else {
                        isStatus = 2;//active
                      }

                      mapArray.push({
                        CratedDtp: new Date(item.StartDtp),
                        DealId: item.DealId,
                        DealStatus: item.DealStatus,
                        Description: item.Description,
                        EmailId: item.EmailId,
                        FeatureImage: item.FeatureImage + "?" + new Date(),
                        FinishDtp: item.FinishDtp != null ? moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD') : null,
                        FinishDtpTime: item.FinishDtp != null ? moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss') : null,
                        Latitude: item.Latitude,
                        Longitude: item.Longitude,
                        MaxCount: item.MaxCount,
                        ModifiedDtp: item.ModifiedDtp,
                        RepeatFinishDtp: item.RepeatFinishDtp != null ? moment.utc(item.RepeatFinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD') : null,
                        RepeatFinishDtpTime: item.RepeatFinishDtp != null ? moment.utc(item.RepeatFinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss') : null,
                        RepeatStartDtp: moment.utc(item.RepeatStartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD'),
                        RepeatStartDtpTime: moment.utc(item.RepeatStartDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss'),
                        Reschedule: item.Reschedule,
                        StartDtp: moment.utc(item.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD'),
                        StartDtpTime: moment.utc(item.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss'),
                        Stuff: item.Stuff,
                        Title: item.Title,
                        View: false,
                        DealHistoryList: dealList,
                        IsStatus: isStatus
                      });
                    });
                  }
                });
              }
            });
          });
          this.loaderService.display(false);
        }
      });
    }
  }
  getDealEntries(EmailId = null, datacall: DataCallbackDeal) {
    let mapArray = Array<Deal>();
    this.loaderService.display(true);
    let userlist: any;
    user_Role = parseInt(localStorage.getItem("userRole"));
    user_Email = EmailId != null ? EmailId : localStorage.getItem("emailId");
    const timestamp = this.nowUtctime();
    if (user_Role == 0 || EmailId != null) {
      params = {
        TableName: environment.ddbTableName,
        FilterExpression: "#EmailId = :eid",
        ExpressionAttributeNames: {
          "#EmailId": "EmailId"
        },
        ExpressionAttributeValues: {
          ":eid": user_Email
        }
      };
      var docClient = new AWS.DynamoDB.DocumentClient();
      docClient.scan(params, (error, result) => {
        if (error) {
          datacall.dataCallbackDeal(error, null);
          return;
        } else {
          const params1 = {
            TableName: environment.ddbLogTableName,
            FilterExpression: "#EmailId=:EmailId AND (#StartDtp<= :sdtp)",
            ExpressionAttributeNames: {
              "#EmailId": "EmailId",
              "#StartDtp": "StartDtp"
            },
            ExpressionAttributeValues: {
              ":EmailId": user_Email,
              ":sdtp": timestamp
            }
          };
          docClient.scan(params1, (error1, result1) => {
            var isStatus = 0;
            if (error1) {
              datacall.dataCallbackDeal(error1, null);
              return;
            } else {
              result.Items.forEach(function (item) {
                var dealList = new Array<DealHistory>();
                var lastdate = null;
                result1.Items.forEach(function (item1) {
                  if (item.DealId == item1.DealId) {
                    dealList.push({
                      DealHistoryId: item1.DealHistoryId,
                      FinishDtp: item1.FinishDtp != 'null' ? moment.utc(item1.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD HH:mm:ss') : 'null',
                      StartDtp: moment.utc(item1.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD HH:mm:ss'),
                      UseCount: item1.UseCount
                    })
                  }
                });
                if (item.DealStatus == 'false') {
                  isStatus = 3;//disable
                }
                else if (item.FinishDtp == 'null') {
                  isStatus = 2;//active
                }
                else if (item.Reschedule == 'No Repeat') {
                  if (new Date() > moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().toDate()) {
                    isStatus = 1;//inactive
                  }
                  else if (dealList.length > 0) {
                    if (item.MaxCount == dealList[0].UseCount && item.MaxCount != -1) {
                      isStatus = 1;//inactive
                    } else {
                      isStatus = 2;//active
                    }
                  } else {
                    isStatus = 2;//active
                  }
                }
                else {
                  isStatus = 2;//active
                }

                mapArray.push({
                  CratedDtp: item.StartDtp,
                  DealId: item.DealId,
                  DealStatus: item.DealStatus,
                  Description: item.Description,
                  EmailId: item.EmailId,
                  FeatureImage: item.FeatureImage + "?" + new Date(),
                  FinishDtp: item.FinishDtp != null ? moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD') : null,
                  FinishDtpTime: item.FinishDtp != null ? moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss') : null,
                  Latitude: item.Latitude,
                  Longitude: item.Longitude,
                  MaxCount: item.MaxCount,
                  ModifiedDtp: item.ModifiedDtp,
                  RepeatFinishDtp: item.RepeatFinishDtp != null ? moment.utc(item.RepeatFinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD') : null,
                  RepeatFinishDtpTime: item.RepeatFinishDtp != null ? moment.utc(item.RepeatFinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss') : null,
                  RepeatStartDtp: moment.utc(item.RepeatStartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD'),
                  RepeatStartDtpTime: moment.utc(item.RepeatStartDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss'),
                  Reschedule: item.Reschedule,
                  StartDtp: moment.utc(item.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD'),
                  StartDtpTime: moment.utc(item.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss'),
                  Stuff: item.Stuff,
                  Title: item.Title,
                  View: false,
                  DealHistoryList: dealList,
                  IsStatus: isStatus
                });
              });
              datacall.dataCallbackDeal(null, mapArray);
            }
          });
        }
      });
    } else {
      params = {
        TableName: environment.ddbUserTableName,
        ProjectionExpression: "EmailId",
        FilterExpression: "#userRole = :urole",
        ExpressionAttributeNames: {
          "#userRole": "userRole"
        },
        ExpressionAttributeValues: {
          ":urole": 0
        }
      };
      var docClient = new AWS.DynamoDB.DocumentClient();

      docClient.scan(params, (error0, result0) => {
        if (error0) {
          datacall.dataCallbackDeal(error0, null);
          return;
        }
        else {
          result0.Items.forEach(function (uitem) {
            params = {
              TableName: environment.ddbTableName,
              FilterExpression: "#EmailId = :eid",
              ExpressionAttributeNames: {
                "#EmailId": "EmailId"
              },
              ExpressionAttributeValues: {
                ":eid": uitem.EmailId
              }
            };

            docClient.scan(params, (error, result) => {
              if (error) {
                datacall.dataCallbackDeal(error, null);
                return;
              } else {
                const params1 = {
                  TableName: environment.ddbLogTableName,
                  FilterExpression: "#EmailId=:EmailId AND (#StartDtp<= :sdtp)",
                  ExpressionAttributeNames: {
                    "#EmailId": "EmailId",
                    "#StartDtp": "StartDtp"
                  },
                  ExpressionAttributeValues: {
                    ":EmailId": uitem.EmailId,
                    ":sdtp": timestamp
                  }
                };
                docClient.scan(params1, (error1, result1) => {
                  var isStatus = 0;
                  if (error1) {
                    datacall.dataCallbackDeal(error1, null);
                    return;
                  } else {
                    result.Items.forEach(function (item) {
                      var dealList = new Array<DealHistory>();
                      var lastdate = null;
                      result1.Items.forEach(function (item1) {
                        if (item.DealId == item1.DealId) {
                          dealList.push({
                            DealHistoryId: item1.DealHistoryId,
                            FinishDtp: item1.FinishDtp != 'null' ? moment.utc(item1.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD HH:mm:ss') : 'null',
                            StartDtp: moment.utc(item1.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD HH:mm:ss'),
                            UseCount: item1.UseCount
                          })
                        }
                      });
                      if (item.DealStatus == 'false') {
                        isStatus = 3;//disable
                      }
                      else if (item.FinishDtp == 'null') {
                        isStatus = 2;//active
                      }
                      else if (item.Reschedule == 'No Repeat') {
                        if (new Date() > moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().toDate()) {
                          isStatus = 1;//inactive
                        }
                        else if (dealList.length > 0) {
                          if (item.MaxCount == dealList[0].UseCount && item.MaxCount != -1) {
                            isStatus = 1;//inactive
                          } else {
                            isStatus = 2;//active
                          }
                        } else {
                          isStatus = 2;//active
                        }
                      }
                      else {
                        isStatus = 2;//active
                      }

                      mapArray.push({
                        CratedDtp: item.StartDtp,
                        DealId: item.DealId,
                        DealStatus: item.DealStatus,
                        Description: item.Description,
                        EmailId: item.EmailId,
                        FeatureImage: item.FeatureImage + "?" + new Date(),
                        FinishDtp: item.FinishDtp != null ? moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD') : null,
                        FinishDtpTime: item.FinishDtp != null ? moment.utc(item.FinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss') : null,
                        Latitude: item.Latitude,
                        Longitude: item.Longitude,
                        MaxCount: item.MaxCount,
                        ModifiedDtp: item.ModifiedDtp,
                        RepeatFinishDtp: item.RepeatFinishDtp != null ? moment.utc(item.RepeatFinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD') : null,
                        RepeatFinishDtpTime: item.RepeatFinishDtp != null ? moment.utc(item.RepeatFinishDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss') : null,
                        RepeatStartDtp: moment.utc(item.RepeatStartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD'),
                        RepeatStartDtpTime: moment.utc(item.RepeatStartDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss'),
                        Reschedule: item.Reschedule,
                        StartDtp: moment.utc(item.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('YYYY-MM-DD'),
                        StartDtpTime: moment.utc(item.StartDtp, "YYYY-MM-DD HH:mm:ss").local().format('HH:mm:ss'),
                        Stuff: item.Stuff,
                        Title: item.Title,
                        View: false,
                        DealHistoryList: dealList,
                        IsStatus: isStatus
                      });
                    });
                    datacall.dataCallbackDeal(null, mapArray);
                  }
                });
              }
            });
          });

        }
      });
    }
  }
  updateDealStatus(DealId: string, DealStatus: string) {
    this.loaderService.display(true);
    params = {
      TableName: environment.ddbTableName,
      Key: {
        'DealId': DealId,
      },
      UpdateExpression: 'SET DealStatus = :DealStatus',
      ExpressionAttributeValues: {
        ':DealStatus': DealStatus.toString()
      },
      ReturnValues: 'ALL_NEW',
    };
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.update(params, (error, result) => {
      if (error) {
        console.error("0", JSON.stringify(error, null, 2));
        this.loaderService.display(false);
      } else {
        const req = {
          DealId: DealId,
          DealStatus: DealStatus,
          Title: result.Attributes.Title
        }
        this.pushOnDealDisable(req);
        const params2 = {
          TableName: environment.ddbLogTableName,
          FilterExpression: "#DealId = :did",
          ExpressionAttributeNames: {
            "#DealId": "DealId"
          },
          ExpressionAttributeValues: {
            ":did": DealId
          }
        };
        docClient.scan(params2, (error1, result1) => {
          if (error1) {

            this.loaderService.display(false);
          } else {
            result1.Items.forEach(function (item) {
              const paramsupdate = {
                TableName: environment.ddbLogTableName,
                Key: {
                  'DealHistoryId': item.DealHistoryId,
                },
                UpdateExpression: 'SET DealStatus = :DealStatus',
                ExpressionAttributeValues: {
                  ':DealStatus': DealStatus.toString()
                },
                ReturnValues: 'UPDATED_NEW',
              };
              docClient.update(paramsupdate, (error2, result2) => {
                if (error2) {
                  console.error("2:", JSON.stringify(error2, null, 2));
                }
                const paramsdeal = {
                  TableName: environment.ddbSnsCronTableName,
                  FilterExpression: "#DealId= :dealid",
                  ExpressionAttributeNames: {
                    "#DealId": "DealId"
                  },
                  ExpressionAttributeValues: {
                    ":dealid": DealId
                  }
                };
                docClient.scan(paramsdeal, (error6, result6) => {
                  if (error6) {

                  }
                  result6.Items.forEach(function (item6) {
                    const paramsdeal = {
                      TableName: environment.ddbSnsCronTableName,
                      Key: {
                        'CronId': item6.CronId,
                      },
                      UpdateExpression: 'SET DealStatus = :DealStatus',
                      ExpressionAttributeValues: {
                        ':DealStatus': DealStatus
                      },
                      ReturnValues: 'UPDATED_NEW',
                    };
                    docClient.update(paramsdeal, (error7, result7) => {
                      if (error7) {

                      }
                    });
                  });
                });
              });
            });
            this.loaderService.display(false);
          }
        });

      }
    });
  }

  updateDealDetails(dealId: string, dealTitle: string, dealDescription: string, uploadImg: boolean, imgData: string) {
    this.loaderService.display(true);
    params = {
      TableName: environment.ddbTableName,
      Key: {
        'DealId': dealId,
      },
      UpdateExpression: 'SET Title = :Title, Description = :Description',
      ExpressionAttributeValues: {
        ':Title': dealTitle,
        ':Description': dealDescription
      },
      ReturnValues: 'ALL_NEW',
    };
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.update(params, (error, result) => {
      if (error) {
        console.error("0", JSON.stringify(error, null, 2));
        this.loaderService.display(false);
      } else {
        var featureimg = result.Attributes.FeatureImage;
        var eid = result.Attributes.EmailId;
        var keyval = featureimg.replace("https://" + environment.s3bucketName + ".s3.amazonaws.com/" + eid + "/deals/", "");
        if (uploadImg == true) {
          var AWSService = this.getAWS();
          var s3Bucket = new AWSService.S3({
            region: CognitoUtil._REGION,
            accessKeyId: environment.accessKeyId,
            secretAccessKey: environment.secretAccessKey
          });
          s3Bucket.createBucket(function () {
            var buffer = new Buffer(imgData.replace(/^data:image\/\w+;base64,/, ""), 'base64');
            var par = { Bucket: environment.s3bucketName + '/' + + eid + "/deals", Key: keyval, Body: buffer, ContentEncoding: 'base64', ContentType: 'image/jpg' };
            s3Bucket.putObject(par, function (err, data) {
              if (err) {

              } else {

              }
            });
          });
        }
        const params2 = {
          TableName: environment.ddbLogTableName,
          FilterExpression: "#DealId = :did",
          ExpressionAttributeNames: {
            "#DealId": "DealId"
          },
          ExpressionAttributeValues: {
            ":did": dealId
          }
        };
        docClient.scan(params2, (error1, result1) => {
          if (error1) {
            this.loaderService.display(false);
          } else {
            result1.Items.forEach(function (item) {
              const paramsupdate = {
                TableName: environment.ddbLogTableName,
                Key: {
                  'DealHistoryId': item.DealHistoryId,
                },
                UpdateExpression: 'SET Title = :Title, Description = :Description',
                ExpressionAttributeValues: {
                  ':Title': dealTitle,
                  ':Description': dealDescription
                },
                ReturnValues: 'UPDATED_NEW',
              };
              docClient.update(paramsupdate, (error2, result2) => {
                if (error2) {

                } else {
                  const paramsdeal = {
                    TableName: environment.ddbSnsCronTableName,
                    FilterExpression: "#DealId= :dealid",
                    ExpressionAttributeNames: {
                      "#DealId": "DealId"
                    },
                    ExpressionAttributeValues: {
                      ":dealid": dealId
                    }
                  };
                  docClient.scan(paramsdeal, (error6, result6) => {
                    if (error6) {

                    }
                    result6.Items.forEach(function (item) {
                   
                      const paramsdeal = {
                        TableName: environment.ddbSnsCronTableName,
                        Key: {
                          'CronId': item.CronId,
                        },
                        UpdateExpression: 'SET Title = :Title, Description = :Description',
                        ExpressionAttributeValues: {
                          ':Title': dealTitle,
                          ':Description': dealDescription
                        },
                        ReturnValues: 'UPDATED_NEW',
                      };
                      docClient.update(paramsdeal, (error7, result7) => {
                        if (error7) {

                        }
                      });
                    });
                  });
                }
              });
            });
          }
        });
      }
    });
  }

  dealsPublish(data: any, datacall: DataCallback) {
    this.loaderService.display(true);
    data.EmailId = localStorage.getItem("emailId");
    const timestamp = this.nowUtctime();
    const uid = UUID.UUID();
    data.FeatureImage = 'https://' + environment.s3bucketName + '.s3.amazonaws.com/' + data.EmailId + "/deals/" + uid + ".jpg"
    const StartDtp = data.StartDtp == '' ? timestamp : data.StartDtp;
    const FinishDtp = data.FinishDtp == '' ? 'null' : data.FinishDtp;
    var AWSService = this.getAWS();
    var s3Bucket = new AWSService.S3({
      region: CognitoUtil._REGION,
      accessKeyId: environment.accessKeyId,
      secretAccessKey: environment.secretAccessKey
    });
    s3Bucket.config.region = CognitoUtil._REGION;

    var paramsuser = {
      TableName: environment.ddbUserTableName,
      FilterExpression: "#EmailId = :eid",
      ExpressionAttributeNames: {
        "#EmailId": "EmailId"
      },
      ExpressionAttributeValues: {
        ":eid": data.EmailId
      },

    };

    var docClient = new AWS.DynamoDB.DocumentClient();

    docClient.scan(paramsuser, (error3, result3) => {
      if (error3) {
        this.loaderService.display(false);
        datacall.dataCallback(error3, "");
      } else {
        data.stuff = result3.Items[0].Stuff;
        data.Latitude = result3.Items[0].CompanyLocation.Latitude;
        data.Longitude = result3.Items[0].CompanyLocation.Longitude;
        data.CompanyName = result3.Items[0].CompanyName;
        data.CompFeatureImage = result3.Items[0].FeatureImage;

        s3Bucket.createBucket(function () {
          var buffer = new Buffer(data.imgData.replace(/^data:image\/\w+;base64,/, ""), 'base64');
          var par = { Bucket: environment.s3bucketName + '/' + data.EmailId + "/deals", Key: uid + ".jpg", Body: buffer, ContentEncoding: 'base64', ContentType: 'image/jpg' };
          s3Bucket.putObject(par, function (err, data) {
            if (err) {
            } else {
            }
          });
        });

        const params = {
          TableName: environment.ddbTableName,
          Item: {
            DealId: UUID.UUID(),
            Title: data.Title,
            Description: data.Description,
            MaxCount: data.MaxCount == 'no limit' ? -1 : parseInt(data.MaxCount),
            StartDtp: StartDtp,
            FinishDtp: FinishDtp,
            Reschedule: data.Reschedule,
            FeatureImage: data.FeatureImage == '' ? 'null' : data.FeatureImage,
            DealStatus: 'true',
            CratedDtp: timestamp,
            ModifiedDtp: timestamp,
            EmailId: data.EmailId,
            Stuff: data.stuff,
            RepeatStartDtp: this.reschedule(StartDtp, data.Reschedule),
            RepeatFinishDtp: data.Reschedule == "No Repeat" ? "null" : this.reschedule(FinishDtp, data.Reschedule),
            Latitude: data.Latitude,
            Longitude: data.Longitude
          },
        }
        docClient.put(params, (error, result) => {
          if (error) {
            datacall.dataCallback(error, null);
          }
          params.Item['CompanyName'] = data.CompanyName;
          params.Item['CompFeatureImage'] = data.CompFeatureImage;
          const responsehistory = this.addHistoryLog(params.Item, false);
          if (data.Reschedule != "" && data.Reschedule != "No Repeat") {
            params.Item.StartDtp = params.Item.RepeatStartDtp;
            params.Item.FinishDtp = params.Item.RepeatFinishDtp;
            const responsehistorynext = this.addHistoryLog(params.Item, false);
            if (new Date(StartDtp) <= new Date(timestamp)) {
              const pushSns = this.pushSnsOnCreateDeal(params.Item);
            }
            datacall.dataCallback(error, null);
          } else {
            if (new Date(StartDtp) <= new Date(timestamp)) {
              const pushSns = this.pushSnsOnCreateDeal(params.Item);
            }
            datacall.dataCallback(null, result);
          }
        });
      }
    });

  }

  addHistoryLog(req, flag) {
    var historyId = UUID.UUID();
    const paramslog = {
      TableName: environment.ddbLogTableName,
      Item: {
        DealHistoryId: historyId,
        DealId: req.DealId,
        Title: req.Title,
        Description: req.Description,
        MaxCount: parseInt(req.MaxCount),
        StartDtp: req.StartDtp,
        FinishDtp: req.FinishDtp,
        FeatureImage: req.FeatureImage,
        DealStatus: req.DealStatus,
        CratedDtp: req.CratedDtp,
        ModifiedDtp: req.ModifiedDtp,
        QrcodeText: UUID.UUID(),
        UseCount: 0,
        EmailId: req.EmailId,
        Stuff: req.Stuff,
        Latitude: req.Latitude,
        Longitude: req.Longitude,
        CompanyName: req.CompanyName,
        CompFeatureImage: req.CompFeatureImage,
        Reschedule: req.Reschedule
      },
    };
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.put(paramslog, (error1, result1) => {
      if (error1) {
      } else {
        const paramslog1 = {
          TableName: environment.ddbSnsCronTableName,
          Item: {
            CronId: UUID.UUID(),
            DealHistoryId: historyId,
            DealId: paramslog.Item.DealId,
            Title: paramslog.Item.Title,
            Description: paramslog.Item.Description,
            TargetArn: null,
            StartDtp: paramslog.Item.StartDtp,
            FinishDtp: paramslog.Item.FinishDtp,
            Stuff: paramslog.Item.Stuff,
            Latitude: parseFloat(paramslog.Item.Latitude),
            Longitude: parseFloat(paramslog.Item.Longitude),
            SentArn: [],
            DealStatus: true
          },
        };
        docClient.put(paramslog1, (error2, result2) => {
          if (error1) {
            return '1';
          } else {
            if (flag == true) {
              const paramsdeal = {
                TableName: environment.ddbTableName,
                Key: {
                  'DealId': paramslog.Item.DealId,
                },
                UpdateExpression: 'SET RepeatStartDtp = :RepeatStartDtp,RepeatFinishDtp = :RepeatFinishDtp',
                ExpressionAttributeValues: {
                  ':RepeatStartDtp': paramslog.Item.StartDtp,
                  ':RepeatFinishDtp': paramslog.Item.FinishDtp
                },
                ReturnValues: 'UPDATED_NEW',
              };
              docClient.update(paramsdeal, (error, result) => {
                if (error) {

                }

              });
            }
          }
        });
      }
    });
  };

  /* SNS Push Notification */

  pushOnDealDisable(req) {
    var sns = new AWS.SNS();
    const params = {
      TableName: environment.ddbSnsTableName,
      FilterExpression: "#DealId = :did",
      ExpressionAttributeNames: {
        "#DealId": "DealId"
      },
      ExpressionAttributeValues: {
        ":did": req.DealId
      }
    };
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.scan(params, (error, result) => {
      if (error) {
      } else {
        result.Items.forEach(function (items) {
          var paramssnspublish = {
            Message: req.Title + "," + "Unfortunately this deal is not active anymore,",
            Subject: "'" + req.Title + "'Deal is expire",
            TargetArn: items.TargetArn
          };
          sns.publish(paramssnspublish, function (err, data) {
            if (err) {
            } else {

            }
          });
          const paramssns = {
            TableName: environment.ddbSnsTableName,
            Key: {
              'DealSnsId': items.DealSnsId,
            }
          };
          var docClient1 = new AWS.DynamoDB.DocumentClient();
          docClient1.delete(paramssns, (error, result) => {
            if (error) {
            } else {
            }
          });
        });
        if (result.count == 0) {
        }
      }
    });
  }

  pushSnsOnCreateDeal(req) {
    //console.log(req.DealId);
    var sns = new AWS.SNS();
    const params1 = {
      TableName: environment.ddbWaagiAppTableName,
      FilterExpression: "#Dining = :Dining or #Clothing = :Clothing or #Electronnics = :Electronnics or #Groceries = :Groceries or #OtherStuff = :OtherStuff",
      ExpressionAttributeNames: {
        "#Dining": "Dining",
        "#Clothing": "Clothing",
        "#Electronnics": "Electronnics",
        "#Groceries": "Groceries",
        "#OtherStuff": "OtherStuff"
      },
      ExpressionAttributeValues: {
        ":Dining": req.Stuff == "Dining" ? 'true' : 'false',
        ":Electronnics": req.Stuff == "Electronics" ? 'true' : 'false',
        ":Groceries": req.Stuff == "Groceries" ? 'true' : 'false',
        ":OtherStuff": req.Stuff == "Other Stuff" ? 'true' : 'false',
        ":Clothing": req.Stuff == "Clothing" ? 'true' : 'false'
      }
    }
    var docClient = new AWS.DynamoDB.DocumentClient();
    docClient.scan(params1, (error1, result1) => {
      if (error1) {

      } else {
        if (result1.Count != 0) {
          result1.Items.forEach(function (item) {
            var distance = parseInt(item.Distance);
            var t = geolib.isPointInCircle({ latitude: parseFloat(item.Latitude), longitude: parseFloat(item.Longitude) }, { latitude: req.Latitude, longitude: req.Longitude },
              distance
            )
            if (t == true) {
              const getdateUTC = moment.utc();
              const timestamp = moment(getdateUTC).format('YYYY-MM-DD HH:mm:ss');
              const paramsdeal = {
                TableName: environment.ddbSnsCronTableName,
                FilterExpression: "#DealId= :dealid AND #StartDtp<= :Sdtp AND #FinishDtp>= :Fdtp",
                ExpressionAttributeNames: {
                  "#DealId": "DealId",
                  "#StartDtp": "StartDtp",
                  "#FinishDtp": "FinishDtp"
                },
                ExpressionAttributeValues: {
                  ":dealid": req.DealId,
                  ":Fdtp": timestamp,
                  ":Sdtp": timestamp
                }
              };
              docClient.scan(paramsdeal, (error6, result6) => {
                if (error6) {

                }
                if (result6.Items.length > 0) {
                  const paramsdeal = {
                    TableName: environment.ddbSnsCronTableName,
                    Key: {
                      'CronId': result6.Items[0].CronId,
                    },
                    UpdateExpression: 'set #SentArn = list_append(if_not_exists(#SentArn, :empty_list), :SentArn)',
                    ExpressionAttributeNames: {
                      '#SentArn': 'SentArn'
                    },
                    ExpressionAttributeValues: {
                      ':SentArn': [item.TargetArn],
                      ':empty_list': []
                    },
                    ReturnValues: 'UPDATED_NEW',
                  };
                  docClient.update(paramsdeal, (error7, result7) => {
                    if (error7) {
                      return 1;
                    }
                    var paramssnspublish = {
                      Message: "New deal available!," + req.Title + " : " + req.Description + "," + req.DealId,
                      Subject: "New deal Create.",
                      TargetArn: item.TargetArn
                    };
                    sns.publish(paramssnspublish, function (err, data) {
                      if (err) {

                      } else {

                      }
                    });
                  });
                } else {

                }
              });
            }
          });
        } else {

        }
      }
    });
  }

  /* Date Format */

  reschedule = function (dtp, terms) {
    const termsevl = terms == 'every day' ? 1 : terms == 'every month' ? 30 : terms == 'every week' ? 7 : terms == 'every 2 week' ? 14 : 0;
    const termsratep = 'days';
    const date = moment(dtp).add(termsevl, termsratep);
    const dateformat = moment(date).format('YYYY-MM-DD HH:mm:ss');
    return dateformat;
  };

  utctime(dtp, timezone) {
    if (dtp != '') {
      const setdatetimezone = momenttz.tz(dtp, 'YYYY-MM-DD HH:mm:ss', timezone);
      const getdateUTC = setdatetimezone.utc();
      const dateformat = moment(getdateUTC).format('YYYY-MM-DD HH:mm:ss');
      return dateformat;
    } else {
      return '';
    }
  };

  nowUtctime() {
    const getdateUTC = moment.utc();
    const dateformat = moment(getdateUTC).format('YYYY-MM-DD HH:mm:ss');
    return dateformat;
  };

  /* Callback */
  cognitoCallback(message: string, result: any) {
    if (message != null) { //error

    } else { //success

    }
  }

  dataCallback(message: string, result: any) {
    if (message != null) { //error

    } else { //success

    }
  }

  dataCallbackDeal(message: string, result: any) {
    if (message != null) { //error

    } else { //success

    }
  }
  locationCallback(message: string, result: any) {
    if (message != null) { //error

    } else { //success

    }
  }
  dataCallbackStatus(message: string, result: any) {
    if (message == "0") {
      //console.log(result);

    } else {
      // console.log(result);
    }
  }
}
