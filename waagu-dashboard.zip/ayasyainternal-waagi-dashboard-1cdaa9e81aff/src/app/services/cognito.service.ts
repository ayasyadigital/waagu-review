import { Injectable, Inject } from '@angular/core';
import { environment } from "../../environments/environment";

import { CognitoCallback, DataCallback, Callback, LoggedInCallback } from '../interfaces/interfaces';

import { RegistrationUser } from "../models/models";

declare var AWSCognito: any;
declare var AWS: any;

@Injectable()
export class CognitoUtil {

    public static _REGION = environment.region;

    public static _IDENTITY_POOL_ID = environment.identityPoolId;
    public static _USER_POOL_ID = environment.userPoolId;
    public static _CLIENT_ID = environment.clientId;
    public static _ACCESSKEY_ID = environment.accessKeyId;
    public static _SECRETKEY_ID = environment.secretAccessKey;
    public static _ROLE_ARN = environment.RoleArn;
    public static _GroupName_Admin = environment.GroupNameAdmin
    public static _POOL_DATA = {
        UserPoolId: CognitoUtil._USER_POOL_ID,
        ClientId: CognitoUtil._CLIENT_ID
    };


    public static getAwsCognito(): any {
        return AWSCognito
    }

    getUserPool() {
        return new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool(CognitoUtil._POOL_DATA);
    }

    getCurrentUser() {
        return this.getUserPool().getCurrentUser();
    }


    getCognitoIdentity(): string {
        return AWS.config.credentials.identityId;
    }

    getAccessToken(callback: Callback): void {
        if (callback == null) {
            throw ("CognitoUtil: callback in getAccessToken is null...returning");
        }
        if (this.getCurrentUser() != null)
            this.getCurrentUser().getSession(function (err, session) {
                if (err) {
                    //console.log(("CognitoUtil: Can't set the credentials:" + err);
                    callback.callbackWithParam(null);
                }

                else {
                    if (session.isValid()) {
                        callback.callbackWithParam(session.getAccessToken().getJwtToken());
                    }
                }
            });
        else
            callback.callbackWithParam(null);
    }

    getIdToken(callback: Callback): void {
        if (callback == null) {
            throw ("CognitoUtil: callback in getIdToken is null...returning");
        }
        if (this.getCurrentUser() != null)
            this.getCurrentUser().getSession(function (err, session) {
                if (err) {
                    //console.log(("CognitoUtil: Can't set the credentials:" + err);
                    callback.callbackWithParam(null);
                }
                else {
                    if (session.isValid()) {
                        callback.callbackWithParam(session.getIdToken().getJwtToken());
                    } else {
                        //console.log(("CognitoUtil: Got the id token, but the session isn't valid");
                    }
                }
            });
        else
            callback.callbackWithParam(null);
    }

    getRefreshToken(callback: Callback): void {
        if (callback == null) {
            throw ("CognitoUtil: callback in getRefreshToken is null...returning");
        }
        if (this.getCurrentUser() != null) {
            this.getCurrentUser().getSession(function (err, session) {
                //console.log(err);
                if (err) {
                    //console.log(("CognitoUtil: Can't set the credentials:" + err);
                    callback.callbackWithParam(null);
                }

                else {
                    if (session.isValid()) {


                        callback.callbackWithParam(session.getRefreshToken());
                    }
                }
            });
        }
        else {
            callback.callbackWithParam(null);
        }
    }

    refresh(): void {
        this.getCurrentUser().getSession(function (err, session) {
            if (err) {
                //console.log(("CognitoUtil: Can't set the credentials:" + err);
            }

            else {
                if (session.isValid()) {
                    //console.log(("CognitoUtil: refreshed successfully");
                } else {
                    //console.log(("CognitoUtil: refreshed but session is still not valid");
                }
            }
        });
    }
}

@Injectable()
export class UserRegistrationService {

    constructor( @Inject(CognitoUtil) public cognitoUtil: CognitoUtil) {

    }

    register(user: RegistrationUser, callback: CognitoCallback): void {
        let attributeList = [];

        let dataEmail = {
            Name: 'email',
            Value: user.email
        };
        let dataNickname = {
            Name: 'given_name',
            Value: user.name
        };
        let phonenumber = {
            Name: 'phone_number',
            Value: '+911234567890'
        };
        attributeList.push(new AWSCognito.CognitoIdentityServiceProvider.CognitoUserAttribute(dataEmail));
        attributeList.push(new AWSCognito.CognitoIdentityServiceProvider.CognitoUserAttribute(dataNickname));
        attributeList.push(new AWSCognito.CognitoIdentityServiceProvider.CognitoUserAttribute(phonenumber));

        this.cognitoUtil.getUserPool().signUp(user.email, user.password, attributeList, null, function (err, result) {
            if (err) {
                callback.cognitoCallback(err.message, null);
            } else {
                callback.cognitoCallback(null, result);
            }
        });

    }

    confirmRegistration(username: string, confirmationCode: string, callback: CognitoCallback): void {

        let userData = {
            Username: username,
            Pool: this.cognitoUtil.getUserPool()
        };

        let cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);

        cognitoUser.confirmRegistration(confirmationCode, true, function (err, result) {
            if (err) {
                callback.cognitoCallback(err.message, null);
            } else {
                callback.cognitoCallback(null, result);
            }
        });
    }

    resendCode(username: string, callback: CognitoCallback): void {
        let userData = {
            Username: username,
            Pool: this.cognitoUtil.getUserPool()
        };

        let cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);

        cognitoUser.resendConfirmationCode(function (err, result) {
            if (err) {
                callback.cognitoCallback(err.message, null);
            } else {
                callback.cognitoCallback(null, result);
            }
        });
    }
    autoAuthenticate(username: string, password: string, callback: LoggedInCallback) {
        // Need to provide placeholder keys unless unauthorised user access is enabled for user pool
        AWSCognito.config.update({ accessKeyId: 'anything', secretAccessKey: 'anything' })

        let authenticationData = {
            Username: username,
            Password: password,
        };
        let authenticationDetails = new AWSCognito.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);

        let userData = {
            Username: username,
            Pool: this.cognitoUtil.getUserPool()
        };
        let cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);
        cognitoUser.authenticateUser(authenticationDetails, {
            onSuccess: function (result) {

                var logins = {}
                logins['cognito-idp.' + CognitoUtil._REGION + '.amazonaws.com/' + CognitoUtil._USER_POOL_ID] = result.getIdToken().getJwtToken();

                // Add the User's Id Token to the Cognito credentials login map.
                AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                    IdentityPoolId: CognitoUtil._IDENTITY_POOL_ID,
                    Logins: logins
                });
                AWS.config.credentials.get(function (err) {
                    if (!err) {
                        callback.isLoggedIn("Sucessfully Login", true);
                    } else {
                        callback.isLoggedIn(err.message, false);
                    }
                });

            },
            onFailure: function (err) {
                callback.isLoggedIn(err.message, false);
            }
        });
    }
}


@Injectable()
export class UserLoginService {

    constructor(public cognitoUtil: CognitoUtil) {
    }

    authenticate(username: string, password: string, callback: CognitoCallback) {

        // Need to provide placeholder keys unless unauthorised user access is enabled for user pool
        AWSCognito.config.update({ accessKeyId: 'anything', secretAccessKey: 'anything' })

        let attributesData = {
            Username: username,
            Password: password,
            phone_number: +911234567890
        };
        let authenticationData = {
            Username: username,
            Password: password,
        };
        let authenticationDetails = new AWSCognito.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);

        let userData = {
            Username: username,
            Pool: this.cognitoUtil.getUserPool()
        };

        let cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);
        cognitoUser.authenticateUser(authenticationDetails, {
            onSuccess: function (result) {
                var logins = {}
                logins['cognito-idp.' + CognitoUtil._REGION + '.amazonaws.com/' + CognitoUtil._USER_POOL_ID] = result.getIdToken().getJwtToken();
                // Add the User's Id Token to the Cognito credentials login map.
                AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                    IdentityPoolId: CognitoUtil._IDENTITY_POOL_ID,
                    Logins: logins
                });

                AWS.config.credentials.get(function (err) {

                    if (!err) {
                        callback.cognitoCallback(null, result);
                    } else {
                        callback.cognitoCallback(err.message, null);
                    }
                });
            },
            onFailure: function (err) {
                callback.cognitoCallback(err.message, null);
            },
            newPasswordRequired: function (attributesData) {
                let p = {
                    email: attributesData.Username,
                    phone_number: "+911234567890"
                };

                cognitoUser.completeNewPasswordChallenge(password, p, this)
            }
        });
    }

    forgotPassword(username: string, callback: CognitoCallback) {
        let userData = {
            Username: username,
            Pool: this.cognitoUtil.getUserPool()
        };

        let cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);

        cognitoUser.forgotPassword({
            onSuccess: function (result) {
                callback.cognitoCallback(null, result);
            },
            onFailure: function (err) {
                callback.cognitoCallback(err.message, null);
            },
            inputVerificationCode() {
                callback.cognitoCallback(null, null);
            }
        });
    }

    confirmNewPassword(email: string, verificationCode: string, password: string, callback: CognitoCallback) {
        let userData = {
            Username: email,
            Pool: this.cognitoUtil.getUserPool()
        };

        let cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);

        cognitoUser.confirmPassword(verificationCode, password, {
            onSuccess: function (result) {
                callback.cognitoCallback(null, result);
            },
            onFailure: function (err) {
                callback.cognitoCallback(err.message, null);
            }
        });
    }

    resendCode(username: string, callback: CognitoCallback): void {
        let userData = {
            Username: username,
            Pool: this.cognitoUtil.getUserPool()
        };

        let cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);

        cognitoUser.resendConfirmationCode(function (err, result) {
            if (err) {
                callback.cognitoCallback(err.message, null);
            } else {
                callback.cognitoCallback(null, result);
            }
        });
    }
    logout() {
        this.cognitoUtil.getCurrentUser().signOut();
    }

    isAuthenticated(callback: LoggedInCallback) {
        if (callback == null)
            throw ("UserLoginService: Callback in isAuthenticated() cannot be null");

        let cognitoUser = this.cognitoUtil.getCurrentUser();

        if (cognitoUser != null) {
            cognitoUser.getSession(function (err, session) {
                if (err) {
                    callback.isLoggedIn(err, false);
                }
                else {
                    callback.isLoggedIn(err, session.isValid());
                }
            });
        } else {
            callback.isLoggedIn("Can't retrieve the CurrentUser", false);
        }
    }

}

@Injectable()
export class UserParametersService {

    constructor(public cognitoUtil: CognitoUtil) {
    }

    getParameters(callback: Callback) {
        let cognitoUser = this.cognitoUtil.getCurrentUser();

        if (cognitoUser != null) {
            cognitoUser.getSession(function (err, session) {
                if (err) {

                }
                else {
                    cognitoUser.getUserAttributes(function (err, result) {
                        if (err) {

                        } else {
                            callback.callbackWithParam(result);
                        }
                    });
                }

            });
        } else {
            callback.callbackWithParam(null);
        }


    }
    updateParameters(companyname: string, callback: CognitoCallback) {
        let cognitoUser = this.cognitoUtil.getCurrentUser();

        if (cognitoUser != null) {
            cognitoUser.getSession(function (err, session) {
                if (err) {

                }
                else {
                    var attributeList = [];
                    var attribute = {
                        Name: 'given_name',
                        Value: companyname
                    };
                    var attributep = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserAttribute(attribute);
                    attributeList.push(attributep);
                    cognitoUser.updateAttributes(attributeList, function (err, result) {
                        if (err) {
                            callback.cognitoCallback(null, err);
                        } else {
                            callback.cognitoCallback(null, result);
                        }
                    });
                }

            });
        } else {
            callback.cognitoCallback(null, null);
        }
    }

    changePassword(oldPassword: string, newPassword: string, callback: CognitoCallback) {
        let cognitoUser = this.cognitoUtil.getCurrentUser();
        if (cognitoUser != null) {
            cognitoUser.getSession(function (err, session) {
                if (err) {
                }
                else {
                    cognitoUser.changePassword(oldPassword, newPassword, function (err, result) {
                        if (err) {
                            callback.cognitoCallback(null, err);
                        } else {
                            callback.cognitoCallback(null, result);
                        }
                    });
                }
            });
        } else {
            callback.cognitoCallback(null, null);
        }
    }
}

@Injectable()
export class UserCognitoService {
    private cognitoservice: any;

    constructor(public cognitoUtil: CognitoUtil) {
        this.cognitoservice = new AWS.CognitoIdentityServiceProvider();
    }

    getCognitoUSerlist(callback: CognitoCallback): void {

        var params = {
            UserPoolId: CognitoUtil._USER_POOL_ID, /* required */
            Limit: 0
        };
        this.cognitoservice.listUsers(params, function (err, data) {
            if (err) {
                callback.cognitoCallback(null, err.stack);
            }
            else {
                // console.log(data);
                callback.cognitoCallback(null, data);
            }           // successful response
        });
    }

    disableUser(username: string, callback: CognitoCallback): void {
        AWS.config.update({
            credentials: new AWS.CognitoIdentityCredentials({
                RoleArn: CognitoUtil._ROLE_ARN,
            })
        });
        AWS.config.update({ accessKeyId: CognitoUtil._ACCESSKEY_ID, secretAccessKey: CognitoUtil._SECRETKEY_ID })
        var cognitoser = new AWS.CognitoIdentityServiceProvider();
        var params = {
            UserPoolId: CognitoUtil._USER_POOL_ID, /* required */
            Username: username /* required */
        };
        cognitoser.adminDisableUser(params, function (err, data) {

            if (err) {
                callback.cognitoCallback(null, err.stack);
            }
            else {
                callback.cognitoCallback(null, data);
            }
        });
    }
    userGlobalSignOut(username: string, callback: CognitoCallback): void {
        AWS.config.update({
            credentials: new AWS.CognitoIdentityCredentials({
                RoleArn: CognitoUtil._ROLE_ARN,
            })
        });
        AWS.config.update({ accessKeyId: CognitoUtil._ACCESSKEY_ID, secretAccessKey: CognitoUtil._SECRETKEY_ID })
        var cognitoser = new AWS.CognitoIdentityServiceProvider();
        var params = {
            UserPoolId: CognitoUtil._USER_POOL_ID,
            Username: username
        };
        cognitoser.adminUserGlobalSignOut(params, function (err1, data1) {
            if (err1) {
                callback.cognitoCallback(null, err1.stack);
            }
            else {
                callback.cognitoCallback(null, data1);
            }
        });
    }
    enableUser(username: string, callback: CognitoCallback): void {
        AWS.config.update({
            credentials: new AWS.CognitoIdentityCredentials({
                RoleArn: CognitoUtil._ROLE_ARN,
            })
        });
        AWS.config.update({ accessKeyId: CognitoUtil._ACCESSKEY_ID, secretAccessKey: CognitoUtil._SECRETKEY_ID })
        var cognitoser = new AWS.CognitoIdentityServiceProvider();
        var params = {
            UserPoolId: CognitoUtil._USER_POOL_ID,
            Username: username
        };
        cognitoser.adminEnableUser(params, function (err, data) {
            if (err) {
                callback.cognitoCallback(null, err.stack);
            }
            else {
                callback.cognitoCallback(null, data);
            }
        });
    }
    updateGorupUser(username: string, isadmin: number, callback: CognitoCallback): void {
        AWS.config.update({
            credentials: new AWS.CognitoIdentityCredentials({
                RoleArn: CognitoUtil._ROLE_ARN,
            })
        });
        AWS.config.update({ accessKeyId: CognitoUtil._ACCESSKEY_ID, secretAccessKey: CognitoUtil._SECRETKEY_ID })
        var cognitoser = new AWS.CognitoIdentityServiceProvider();
        var params = {
            UserPoolId: CognitoUtil._USER_POOL_ID,
            Username: username,
            GroupName: CognitoUtil._GroupName_Admin
        };
        if (isadmin == 0) {
            cognitoser.adminRemoveUserFromGroup(params, function (err, data) {
                if (err) {
                    callback.cognitoCallback(null, err.stack);
                }
                else {
                    callback.cognitoCallback(null, data);
                }
            });
        } else {
            cognitoser.adminAddUserToGroup(params, function (err, data) {
                if (err) {
                    callback.cognitoCallback(null, err.stack);
                }
                else {
                    callback.cognitoCallback(null, data);
                }
            });
        }
    }
    //  checkUser(username: string, callback: DataCallback) {
    //      AWS.config.update({
    //         credentials: new AWS.CognitoIdentityCredentials({
    //             RoleArn: CognitoUtil._ROLE_ARN,
    //         })
    //     });
    //     AWS.config.update({ accessKeyId: CognitoUtil._ACCESSKEY_ID, secretAccessKey: CognitoUtil._SECRETKEY_ID })
    //     var cognitoser = new AWS.CognitoIdentityServiceProvider();
    //     var params = {
    //         UserPoolId: CognitoUtil._USER_POOL_ID, /* required */
    //         Username: username /* required */
    //     };
    //    cognitoser.adminGetUser(params, function (err, data) {
    //         if (err) {
    //             callback.dataCallback("0",err);
    //         }
    //         else {
    //             callback.dataCallback("1",data);
    //         }
    //     });
    // }
    updateParameters(companyname: string, emailId: string, callback: CognitoCallback) {
        var params = {
            UserAttributes: [
                {
                    Name: 'given_name',
                    Value: companyname
                },
            ],
            UserPoolId: CognitoUtil._USER_POOL_ID,
            Username: emailId
        };
        this.cognitoservice.adminUpdateUserAttributes(params, function (err, data) {
            if (err) {
                callback.cognitoCallback(null, err.stack);
            }
            else {
                callback.cognitoCallback(null, data);
            }
        });
    }


}
