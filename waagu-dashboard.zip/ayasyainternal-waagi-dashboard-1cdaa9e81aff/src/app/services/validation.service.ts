import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import * as moment from 'moment';
import * as momenttz from 'moment-timezone';
import { DealsComponent } from '../component/deals/deals.component';

@Injectable()
export class ValidationService {
    static getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
        let config = {
            'required': 'Required',
            'invalidEmailAddress': 'Invalid email address',
            'invalidPassword': 'Invalid password. Password must be at least 6 characters long, and contain a number.',
            'minlength': `Minimum length ${validatorValue.requiredLength}`,
            'invalidDate': 'Invalid Date date must be greater than current date time now',
            'invalidFnishDate': 'Invalid Date date must be greater than start date'
        };
        return config[validatorName];
    }

    static emailValidator(control) {
        if (control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
            return null;
        } else {
            return { 'invalidEmailAddress': true };
        }
    }

    static passwordValidator(control) {
        // {6,100}           - Assert password is between 6 and 100 characters
        // (?=.*[0-9])       - Assert a string has at least one number
        if (control.value.match(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,100}$/)) {
            return null;
        } else {
            return { 'invalidPassword': true };
        }
    }


    static dateValidator(control) {
        var startdate = localStorage.getItem("startdefaultdate");
        var datefTemp = new Date(startdate);
        var datetemp2 = new Date(control.value);
        if (datetemp2 >= datefTemp || control.value == null) {
            return null;
        } else {
            return { 'invalidDate': true };
        }
    }
   
    static specificValueInsideRange(control) {
        if (control.controls.finishDtp.value == null) {
            return null;
        }
        else if (moment(control.controls.finishDtp.value) > moment(control.controls.startDtp.value)) {
            return null;
        } else {
            return { outsideRange: true };
        }
    }
}
