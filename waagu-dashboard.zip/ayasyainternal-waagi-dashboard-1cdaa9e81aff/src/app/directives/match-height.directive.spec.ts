import { MatchHeightDirective } from './match-height.directive';

describe('MatchHeightDirective', () => {
  it('should create an instance', () => {
    const directive = new MatchHeightDirective();
    expect(directive).toBeTruthy();
  });
});
