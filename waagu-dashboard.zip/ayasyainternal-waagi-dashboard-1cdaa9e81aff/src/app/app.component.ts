import { Component, NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

import { AwsUtil } from "./services/aws.service";
import { UserLoginService, UserCognitoService, CognitoUtil } from "./services/cognito.service";
import { LoaderService } from './services/loader.service';
import { LoggedInCallback } from './interfaces/interfaces';
import { AgmCoreModule, MapsAPILoader } from 'angular2-google-maps/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, LoggedInCallback {
  title = "";
  rolebase = 0;
  showLoader: boolean;
  locationpathvalue: any;
  showlocationmsg:boolean=false;
  constructor(
    public ngZone: NgZone,
    public mapsAPILoader: MapsAPILoader,
    public loaderService: LoaderService,
    public awsUtil: AwsUtil,
    public userService: UserLoginService,
    public cognito: CognitoUtil,
    public router: Router) {
    router.events.subscribe((val) => {
      this.rolebase = parseInt(localStorage.getItem("userRole"));
      this.locationpathvalue = this.router.routerState.snapshot.url.match('^/[a-z]+[^/]');
      if (this.locationpathvalue != null) {
        this.title = this.locationpathvalue[0];
      } else {
        this.title = '/login'
      }
    });
  }

  ngOnInit() {
    //this.setCurrentPosition();
    this.userService.isAuthenticated(this);
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });
  }

  setCurrentPosition() {
    //this.loaderService.display(true);
    this.mapsAPILoader.load().then(() => {
      if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition((position) => {
          let geocoder = new google.maps.Geocoder();
          let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
          geocoder.geocode({ 'location': latLng }, (
            (results: google.maps.GeocoderResult[], status: google.maps.GeocoderStatus) => {
              localStorage.setItem("latitude", position.coords.latitude.toFixed(7));
              localStorage.setItem("longitude", position.coords.longitude.toFixed(7));
              //console.log(position.coords);

              if (status === google.maps.GeocoderStatus.OK) {
                localStorage.setItem("address", results[0].formatted_address);
                //console.log(results[0].formatted_address);
              } else {
                localStorage.setItem("address", "");
              }
            })
          );
          //this.showlocationmsg=false;
          //this.loaderService.display(false);
        }, (error) => {
          localStorage.setItem("latitude", null);
          localStorage.setItem("longitude", null);
          localStorage.setItem("address", null);
        // this.showlocationmsg=true;
          //this.loaderService.display(false);
        });
      }
    });
  }

  //Logout from webapp
  isLogout() {
    this.userService.logout();
    var latitude = localStorage.getItem("latitude");
    var longitude = localStorage.getItem("longitude");
    localStorage.clear();
    localStorage.setItem("latitude", latitude);
    localStorage.setItem("longitude", longitude);
    this.router.navigate(['/login']);
  }

  //callback from check login 
  isLoggedIn(message: string, isLoggedIn: boolean) {
    let mythis = this;
    this.cognito.getIdToken({
      callback() {
      },
      callbackWithParam(token: any) {
        mythis.awsUtil.initAwsService(null, isLoggedIn, token);
      }
    });
  }

}
