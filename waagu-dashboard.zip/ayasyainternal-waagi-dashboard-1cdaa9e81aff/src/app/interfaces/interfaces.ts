export interface Callback {
    callback(): void;
    callbackWithParam(result: any): void;
}
export interface DataCallbackStatus {
    dataCallbackStatus(message: string, result: any): void;
}
export interface DataCallback {
    dataCallback(message: string, result: any): void;
}

export interface DataCallbackDeal {
    dataCallbackDeal(message: string, result: any): void;
}
export interface LocationCallback {
    locationCallback(message: string, result: any): void;
}

export interface LoggedInCallback {
    isLoggedIn(message: string, loggedIn: boolean): void;
}

export interface CognitoCallback {
     cognitoCallback(message: string, result: any): void;
}
