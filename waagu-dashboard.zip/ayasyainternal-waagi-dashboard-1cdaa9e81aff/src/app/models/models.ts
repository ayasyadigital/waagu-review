export class Counts {
    usercount: number;
    inactive_usercount: number;

    totalavailableDealsCount: number;
    totaldiningCount: number;
    totalclothingCount: number;
    totalelectronicsCount: number;
    totalgroceriesCount: number;
    totalotherstuffCount: number;

    availableDealsCount: number;
    diningCount: number;
    clothingCount: number;
    electronicsCount: number;
    groceriesCount: number;
    otherstuffCount: number;
    
    inactive_availableDealsCount: number;
    inactive_diningCount: number;
    inactive_clothingCount: number;
    inactive_electronicsCount: number;
    inactive_groceriesCount: number;
    inactive_otherstuffCount: number;
    
    disable_availableDealsCount: number;
    disable_diningCount: number;
    disable_clothingCount: number;
    disable_electronicsCount: number;
    disable_groceriesCount: number;
    disable_otherstuffCount: number;
}

export class Deal {
    CratedDtp: Date;
    DealId: string;
    DealStatus: string;
    Description: string;
    EmailId: string;
    FeatureImage: string;
    FinishDtp: string;
    FinishDtpTime: string;
    Latitude: string;
    Longitude: string;
    MaxCount: string;
    ModifiedDtp: string;
    RepeatFinishDtp: string;
    RepeatFinishDtpTime: string;
    RepeatStartDtp: string;
    RepeatStartDtpTime: string;
    Reschedule: string;
    StartDtp: string;
    StartDtpTime: string;
    Stuff: string;
    Title: string;
    View: boolean;
    DealHistoryList: Array<DealHistory>;
    IsStatus:number;
}

export class DealHistory{
    DealHistoryId: string;
    StartDtp: string;
    FinishDtp: string;
    UseCount:string;

}

export class RegistrationUser {
    name: string;
    email: string;
    password: string;
}

export class Shopsdropdown {
    constructor(public id: number, public name: string) { }
}

export class User {
    Address: string;
    Latitude: number;
    Longitude: number;
    CompanyName: string;
    EmailId: string;
    FeatureImage: string;
    userStatus: string;
    Stuff: string;
    CratedDtp: string;
    userRole: number;
    View: boolean;
}

export class UserSession {
    EmailId: string;
    UserRole: string;
}

export class Parameters {
    name: string;
    value: string;
}

export class AppData {
    Id:string;
    CompanyName: string;
    StoreLatitude:Number;
    StoreLongitude:Number;
    AppLatitude:Number;
    AppLongitude:Number;
    AppDistance:number;
    Distance:number;
    InRadiuse:boolean;
    IsStuff: boolean;
}
