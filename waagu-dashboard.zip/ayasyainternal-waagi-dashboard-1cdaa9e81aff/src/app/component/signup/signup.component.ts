import { Component, OnInit, NgModule, ViewChild, NgZone, } from '@angular/core';
import { Router } from "@angular/router";
import { FormControl, FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ImageCropperComponent, CropperSettings, Bounds } from 'ng2-img-cropper/';
import { BrowserModule } from "@angular/platform-browser";
import { AgmCoreModule, MapsAPILoader } from 'angular2-google-maps/core';

import { RegistrationUser } from '../../models/models';
import { DataCallback, CognitoCallback } from "../../interfaces/interfaces";

import { UserLoginService, UserRegistrationService } from "../../services/cognito.service";
import { ValidationService } from '../../services/validation.service';
import { LoaderService } from '../../services/loader.service';
import { DdbService } from "../../services/ddb.service";


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit, DataCallback {
  public zoom: number = 18;
  public mapdenied:boolean=false;
  public data1: any;
  public cropperSettings1: CropperSettings;
  public croppedWidth: number;
  public croppedHeight: number;
  public loadingmap: boolean = false;
  public itemsShop: any = [
    { label: 'Select Shop', value: null },
    { label: 'Dining', value: 'Dining' },
    { label: 'Clothing', value: 'Clothing' },
    { label: 'Electronics', value: 'Electronics' },
    { label: 'Groceries', value: 'Groceries' },
    { label: 'Other Stuff', value: 'Other Stuff' }];
  private value: any = {};
  private disabled: boolean = false;
  public req: any;
  public lat: number = null;
  public lng: number = null;
  public markers: any;
  public address: string = null;
  signupForm: any;
  errorMessage: any;
  registrationUser: RegistrationUser;
public isMap:boolean=true;
  @ViewChild('cropper', undefined) cropper: ImageCropperComponent;

  public searchControl: FormControl;
  @ViewChild("search")
  public searchElementRef: any;
  constructor(
    public ngZone: NgZone,
    public mapsAPILoader: MapsAPILoader,
    public loaderService: LoaderService,
    public router: Router,
    public ddb: DdbService,
    private formBuilder: FormBuilder,
    public userRegistrationService: UserRegistrationService,
  ) {
    this.signupForm = this.formBuilder.group({
      'companyName': ['', ''],
      'email': ['', [Validators.required, ValidationService.emailValidator]],
      'password': ['', [Validators.required]],
      'selectedShop': ['', [Validators.required]]
    });

    this.cropperSettings1 = new CropperSettings();
    this.cropperSettings1.width = 250;
    this.cropperSettings1.height = 250;

    this.cropperSettings1.croppedWidth = 250;
    this.cropperSettings1.croppedHeight = 250;

    this.cropperSettings1.canvasWidth = 280;
    this.cropperSettings1.canvasHeight = 280;

    this.cropperSettings1.minWidth = 100;
    this.cropperSettings1.minHeight = 100;

    this.cropperSettings1.rounded = false;
    this.cropperSettings1.keepAspect = true;
    this.cropperSettings1.cropperDrawSettings.strokeColor = 'rgba(255,255,255,1)';
    this.cropperSettings1.cropperDrawSettings.strokeWidth = 2;
    this.data1 = {};
    this.req = {};
    // this.lat = localStorage.getItem("latitude")=="null"?parseFloat("-17.750676"): parseFloat(localStorage.getItem("latitude"));
    // this.lng = localStorage.getItem("longitude")=="null"?parseFloat("74.144123"):parseFloat(localStorage.getItem("longitude"));
    // this.address = localStorage.getItem("address")=="null"?null :localStorage.getItem("address"); 

    // if(localStorage.getItem("latitude")!="null"){
    //   this.markers=[{lat:this.lat,lng:this.lng,address:this.address}];
    // }
    
  }

  ngOnInit() {
    this.searchControl = new FormControl();
    this.mapsAPILoader.load().then(() => {
      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ["address"]
      });
      autocomplete.addListener("place_changed", () => {
        this.isMap=false;
        this.ngZone.run(() => {
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }
          this.lat = place.geometry.location.lat();
          this.lng = place.geometry.location.lng();
          this.address = place.formatted_address;
          this.markers=[];
          this.markers.push({lat:this.lat,lng:this.lng,address:this.address});
          this.isMap=true;
        });
      });
    });

    this.registrationUser = new RegistrationUser();
    this.errorMessage = null;
    this.setCurrentPosition();
  }


  mapClicked($event: any) {
    this.isMap=false;
    this.loaderService.display(true);
    this.mapsAPILoader.load().then(() => {
      let geocoder = new google.maps.Geocoder();
      let latLng = new google.maps.LatLng($event.coords.lat, $event.coords.lng);
      geocoder.geocode({ 'location': latLng }, (
        (results: google.maps.GeocoderResult[], status: google.maps.GeocoderStatus) => {
          this.lat = parseFloat($event.coords.lat.toFixed(7));
          this.lng = parseFloat($event.coords.lng.toFixed(7));
          this.address = "not found";
          if (status === google.maps.GeocoderStatus.OK) {
            this.address = results[0].formatted_address; 
            this.markers=[];
            this.markers.push({lat:this.lat,lng:this.lng,address:this.address});              
          }else{
            this.address ="no address";
            this.markers=[];
            this.markers.push({lat:this.lat,lng:this.lng,address:this.address});
            this.isMap=true;  
          }
        })
      );
      setTimeout(() => {
        this.isMap=true;  
        this.loaderService.display(false);
        },1000);
    });
  }
  setCurrentPosition() {
    this.isMap=false;
    this.loaderService.display(true);
    this.mapsAPILoader.load().then(() => {
      if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition((position) => {
          let geocoder = new google.maps.Geocoder();
          let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
          geocoder.geocode({ 'location': latLng }, (
            (results: google.maps.GeocoderResult[], status: google.maps.GeocoderStatus) => {
              this.lat=parseFloat(position.coords.latitude.toFixed(7));
              this.lng=parseFloat(position.coords.longitude.toFixed(7));
             // console.log(position.coords);
              this.markers=[];
              if (status === google.maps.GeocoderStatus.OK) {
                this.address= results[0].formatted_address;
                //console.log(results[0].formatted_address);
                this.markers.push({lat:this.lat,lng:this.lng,address:this.address});
              } else {
                this.markers.push({lat:this.lat,lng:this.lng,address:""});
              }
            })
          );
          setTimeout(() => {
            this.isMap=true;  
            this.loaderService.display(false);
            },1000);
        }, (error) => {
          this.mapdenied=true;
          this.isMap=true;
          this.loaderService.display(false);
        });
      }
    });
  }
 
  onRegister() {
    this.loaderService.display(true);
    this.registrationUser.email = this.signupForm.value.email;
    this.registrationUser.name = this.signupForm.value.companyName;
    this.registrationUser.password = this.signupForm.value.password;
    this.req = {
      CompanyName: this.signupForm.value.companyName,
      EmailId: this.signupForm.value.email,
      Password: this.signupForm.value.password,
      Longitude: this.lng,
      Latitude: this.lat,
      Address: this.address,
      Stuff: this.signupForm.value.selectedShop,
      imgData: this.data1.image,
      FeatureImage: ""
    }
    this.errorMessage = null;
    this.userRegistrationService.register(this.registrationUser, this);
  }

  gotoConfirm() {
    this.router.navigate(['/signup', this.signupForm.value.email]);
  }

  cropped(bounds: Bounds) {
    this.croppedHeight = bounds.bottom - bounds.top;
    this.croppedWidth = bounds.right - bounds.left;
  }

  fileChangeListener($event) {
    var image: any = new Image();
    var file: File = $event.target.files[0];
    var myReader: FileReader = new FileReader();
    var that = this;
    myReader.onloadend = function (loadEvent: any) {
      image.src = loadEvent.target.result;
      that.cropper.setImage(image);
    };
    myReader.readAsDataURL(file);
  }
  cognitoCallback(message: string, result: any) {
    if (message != null) {
      this.errorMessage = message;
      this.loaderService.display(false);
      window.scrollTo(0, 0);
    } else {
      this.ddb.userSignup(this.req, this);
    }
  }
  dataCallback(message: string, result: any) {
    if (message != null) {
      this.errorMessage = message;
      this.loaderService.display(false);
      window.scrollTo(0, 0);
    } else {
      this.data1 = {};
      this.signupForm = this.formBuilder.group({
        'companyName': ['', ''],
        'email': ['', [Validators.required, ValidationService.emailValidator]],
        'password': ['', [Validators.required]],
        'selectedShop': ['', [Validators.required]]
      });
      this.lat = null;
      this.lng = null;
      this.address = null;
      this.loaderService.display(false);
      this.router.navigate(['/signup', this.req.EmailId]);
    }
  }
  validateform() {
    if (this.signupForm.valid != true || this.data1.image == undefined || this.lat == null || this.lng == null || this.address == null) {
      return true;
    } else {
      return false;
    }
  }
}
