import { Component, OnDestroy, ViewChild, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { ImageCropperComponent, CropperSettings, Bounds } from 'ng2-img-cropper';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import * as moment from 'moment';
import * as momenttz from 'moment-timezone';
import { environment } from "../../../environments/environment";
import { Deal } from '../../models/models';
import { DataCallback, LoggedInCallback, DataCallbackStatus, DataCallbackDeal } from "../../interfaces/interfaces"
import { UserLoginService, } from "../../services/cognito.service";

import { DdbService } from "../../services/ddb.service";
import { ValidationService } from '../../services/validation.service';
import { LoaderService } from '../../services/loader.service';
import { CategoryPipe } from '../../pipe/category.pipe';
import { OrderByPipe } from '../../pipe/order-by.pipe';
@Component({
  selector: 'app-deals',
  templateUrl: './deals.component.html',
  styleUrls: ['./deals.component.css']
})
export class DealsComponent implements LoggedInCallback, OnDestroy, DataCallback, DataCallbackStatus, OnInit, DataCallbackDeal {

  public deals: Array<Deal> = [];
  private sub: any;
  public email: string;
  public dealId: string;
  public dealTitle: string;
  public dealDescription: string;
  public editMode: boolean;
  public indexEdit: number;
  public uploadImg: boolean;
  public data1: any;
  public cropperSettings1: CropperSettings;
  public croppedWidth: number;
  public croppedHeight: number;
  public addMode: boolean;

  public dealForm: any;
  public rangeForm: any;
  public dealInput: any;
  public items: any = [];
  public itemsRepeat: any = [];
  private value: any = {};
  private disabled: boolean = false;
  private rolebase: string = "1";
  public minDateValue: any;
  public dateValue: any;
  public message: string = null;
  public messagetype: number;

  public startDtpDefault: any;
  public fnishDtpDefault: any;
  public statusPopup: boolean = false;
  public popupId: string;
  public popupIndex: number;
  isDesc: boolean = false;
  column: string = 'CratedDtp';
  direction: number = -1;
  records: Array<any>;
  filterp: boolean = false;
  @ViewChild('cropper', undefined) cropper: ImageCropperComponent;
  constructor(public loaderService: LoaderService,
    private changeDetectorRef: ChangeDetectorRef,
    public router: Router, public route: ActivatedRoute, public ddb: DdbService, public userService: UserLoginService, private formBuilder: FormBuilder) {
    this.userService.isAuthenticated(this);
    this.uploadImg = false;
    //image crop settings
    this.cropperSettings1 = new CropperSettings();
    this.cropperSettings1.width = 300;
    this.cropperSettings1.height = 300;

    this.cropperSettings1.croppedWidth = 300;
    this.cropperSettings1.croppedHeight = 300;

    this.cropperSettings1.canvasWidth = 330;
    this.cropperSettings1.canvasHeight = 330;

    this.cropperSettings1.minWidth = 100;
    this.cropperSettings1.minHeight = 100;

    this.cropperSettings1.rounded = false;
    this.cropperSettings1.keepAspect = true;
    this.cropperSettings1.cropperDrawSettings.strokeColor = 'rgba(255,255,255,1)';
    this.cropperSettings1.cropperDrawSettings.strokeWidth = 2;
    this.data1 = {};

    this.dealInput = {};
    this.addMode = false;
    this.items.push({ label: 'Select available deals', value: null });
    this.items.push({ label: "no limit", value: "no limit" });
    for (var index = 1; index <= 50; index++) {
      this.items.push({ label: index.toString(), value: index.toString() });
    }
    this.rangeForm = this.formBuilder.group({
      'startDtp': ['', [Validators.required, ValidationService.dateValidator]],
      'finishDtp': ['']
    }, {
        validator: ValidationService.specificValueInsideRange.bind(this)
      });
    this.dealForm = this.formBuilder.group({
      'rangeForm': this.rangeForm,
      'Title': ['', [Validators.required]],
      'Description': ['', [Validators.required]],
      'maxcount': ['', [Validators.required]],
      'reschedule': ['', [Validators.required]]
    });
    this.rolebase = localStorage.getItem("userRole");
    localStorage.setItem("startdefaultdate", "");
  }
  ngOnInit() {
    this.ddb.getUserActiveEntries(this);
    this.sub = this.route.params.subscribe(params => {
      this.email = params['email'];
    });
    this.ddb.getDealEntries(this.email, this);
  }
  //check is login or not
  isLoggedIn(message: string, isLoggedIn: boolean) {
    if (!isLoggedIn) {
      this.router.navigate(['/login']);
    } else {

    }
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  //open popup for disable deal
  onOpenPopupChangeStatus(id: string, index: number) {
    this.ddb.getUserActiveEntries(this);
    this.statusPopup = true;
    this.popupId = id;
    this.popupIndex = index;
  }
  //close popup for disable deal
  onClosePopupChangeStatus() {
    this.statusPopup = false;
    this.popupId = null;
    this.popupIndex = null;
  }
  //change disable deal
  onChangeStatus(): void {
    this.ddb.updateDealStatus(this.popupId, 'false');
    setTimeout(() => {
      this.deals[this.popupIndex].IsStatus = 3;
      this.deals[this.popupIndex].DealStatus = 'false';
      this.statusPopup = false;
      this.popupId = null;
      this.popupIndex = null;
      this.loaderService.display(false);
    }, 2000);
  }
  sort(property) {
    this.filterp = false;
    // console.log(property);
    this.isDesc = !this.isDesc; //change the direction    
    this.column = property;
    this.direction = this.isDesc ? 1 : -1;
    alert(this.direction);
    setTimeout(() => {
      this.filterp = true;
    }, 2000);
  };
  //open popup for edit deal
  onEditPopup(dealId: string, dealTitle: string, dealDescription: string, index: number) {
    console.log('hi')
    this.ddb.getUserActiveEntries(this);
    this.editMode = true;
    this.dealId = dealId;
    this.dealTitle = dealTitle;
    this.dealDescription = dealDescription;
    this.uploadImg = false;
    this.indexEdit = index;
    this.data1 = {};

  }

  //close popup for edit deal
  onClosePopup() {
    this.editMode = false;
    this.dealId = "";
    this.dealTitle = "";
    this.dealDescription = "";
    this.uploadImg = false;
    this.data1 = {};
    this.indexEdit = null;
  }

  //update deal details
  onEditUpdate() {
    this.ddb.updateDealDetails(this.dealId, this.dealTitle, this.dealDescription, this.uploadImg, this.data1.image);
    this.editMode = false;
    setTimeout(() => {
      this.deals[this.indexEdit].Title = this.dealTitle;
      this.deals[this.indexEdit].Description = this.dealDescription;
      this.deals[this.indexEdit].FeatureImage = this.deals[this.indexEdit].FeatureImage + "?" + new Date();
      this.deals[this.indexEdit].Title = this.dealTitle;
      this.dealId = "";
      this.dealTitle = "";
      this.dealDescription = "";
      this.uploadImg = false;
      this.indexEdit = null;
      this.data1 = {};
      this.loaderService.display(false);
    }, 8000);
  }

  //validate form edit data
  validateform() {
    if (this.dealTitle == "" || this.dealDescription == "") {
      return true;
    } else {
      return false;
    }
  }

  //open popup for deal publish
  onDealOpenPopup() {
    this.ddb.getUserActiveEntries(this);
    this.addMode = true;
    var datefTemp = this.settime();
    this.minDateValue = datefTemp;
    this.startDtpDefault = new Date(datefTemp);
    datefTemp.setMinutes(datefTemp.getMinutes() + 5);
    this.fnishDtpDefault = new Date(datefTemp);
    localStorage.setItem("startdefaultdate", this.startDtpDefault);
    this.itemsRepeat = [];
    this.itemsRepeat.push({ label: 'Select repeat', value: null });
    this.itemsRepeat.push({ label: 'No Repeat', value: 'No Repeat' });
    this.dealInput.Reschedule = "No Repeat";
  }

  //close popup for deal publish
  onDealClosePopup() {
    this.addMode = false;
    this.dealInput = {};
    this.message = null;

    this.rangeForm = this.formBuilder.group({
      'startDtp': ['', [Validators.required, ValidationService.dateValidator]],
      'finishDtp': ['']
    }, {
        validator: ValidationService.specificValueInsideRange.bind(this)
      });
    this.dealForm = this.formBuilder.group({
      'rangeForm': this.rangeForm,
      'Title': ['', [Validators.required]],
      'Description': ['', [Validators.required]],
      'maxcount': ['', [Validators.required]],
      'reschedule': ['', [Validators.required]]
    });
    localStorage.setItem("startdefaultdate", "");
  }

  //deal publish
  dealPublish() {
    if (this.dealForm.dirty && this.dealForm.valid) {
      this.message = null;
      var req = {
        Title: this.dealInput.Title,
        Description: this.dealInput.Description,
        MaxCount: this.dealInput.MaxCount,
        StartDtp: moment(this.dealInput.StartDtp).utc().format('YYYY-MM-DD HH:mm:ss'),
        FinishDtp: this.dealInput.FinishDtp != null ? moment(this.dealInput.FinishDtp).utc().format('YYYY-MM-DD HH:mm:ss') : 'null',
        Reschedule: this.dealInput.Reschedule,
        imgData: this.data1.image,
        FeatureImage: "",
        EmailId: "",
        stuff: "",
        Latitude: null,
        Longitude: null,
        CompanyName: "",
        CompFeatureImage: "",
      }
      this.ddb.dealsPublish(req, this)
    }
  }
  //data callback from data
  dataCallbackStatus(message: string, result: any) {
    if (message == "0") {
      //console.log(result);

    } else {
      if (result == 'false') {
        this.userService.logout();
        this.router.navigate(['/login']);
      }
      // console.log(result);
    }
  }

  dataCallbackDeal(message: string, result: any) {
    if (message != null) { //error

    } else { //success
      this.deals = result;
      this.loaderService.display(false);
    }
  }
  dataCallback(message: string, result: any) {
    if (message != null) {
      this.messagetype = 0;
      this.message = message;
      this.loaderService.display(false);
    } else {
      this.messagetype = 1;
      this.message = "Deal publish successfully";

      setTimeout(() => {
        this.message = null;
        this.addMode = false;
        this.dealInput = {};
        this.deals = [];
        this.rangeForm = this.formBuilder.group({
          'startDtp': ['', [Validators.required, ValidationService.dateValidator]],
          'finishDtp': ['']
        }, {
            validator: ValidationService.specificValueInsideRange.bind(this)
          });
        this.dealForm = this.formBuilder.group({
          'rangeForm': this.rangeForm,
          'Title': ['', [Validators.required]],
          'Description': ['', [Validators.required]],
          'maxcount': ['', [Validators.required]],
          'reschedule': ['', [Validators.required]]
        });
        this.sub = this.route.params.subscribe(params => {
          this.email = params['email'];
        });
        localStorage.setItem("startdefaultdate", "");
        //this.ddb.getDealEntries(this.deals, this.email);
        this.ddb.getDealEntries(this.email, this);
      }, 1000);
      this.loaderService.display(false);
    }
  }

  //upload image or not set
  changeFetureModel() {
    this.uploadImg == true ? this.uploadImg = false : this.uploadImg = true;
    this.data1 = {};
  }
  //croping function
  cropped(bounds: Bounds) {
    this.croppedHeight = bounds.bottom - bounds.top;
    this.croppedWidth = bounds.right - bounds.left;
  }
  //file change listener
  fileChangeListener($event) {
    var image: any = new Image();
    var file: File = $event.target.files[0];
    var myReader: FileReader = new FileReader();
    var that = this;
    myReader.onloadend = function (loadEvent: any) {
      image.src = loadEvent.target.result;
      that.cropper.setImage(image);
    };
    myReader.readAsDataURL(file);
  }
  //set Repeat baseon start and end date
  onSelectMethod($event, flg) {
    this.itemsRepeat = [];
    this.itemsRepeat.push({ label: 'Select repeat', value: null });
    this.itemsRepeat.push({ label: 'No Repeat', value: 'No Repeat' });
    var input1 = flg == 'start' ? $event : this.dealInput.StartDtp;
    var input2 = flg == 'end' ? $event : this.dealInput.FinishDtp;
    if (input1 != null && input2 != null) {
      var startdtp = moment(this.dealInput.StartDtp);
      var finishdtp = moment($event);
      var duration = moment.duration(finishdtp.diff(startdtp));
      var hours = duration.asHours();
      var minutes = duration.asMinutes();
      var week = duration.asWeeks();
      var month = duration.asMonths();
      if (hours <= 24) {
        this.itemsRepeat.push({ label: 'every day', value: 'every day' });
        this.itemsRepeat.push({ label: 'every week', value: 'every week' });
        this.itemsRepeat.push({ label: 'every 2 week', value: 'every 2 week' });
        this.itemsRepeat.push({ label: 'every month', value: 'every month' });
      } else if (hours >= 24 && week <= 1) {
        this.itemsRepeat.push({ label: 'every week', value: 'every week' });
        this.itemsRepeat.push({ label: 'every 2 week', value: 'every 2 week' });
        this.itemsRepeat.push({ label: 'every month', value: 'every month' });
      } else if (hours >= 24 && week >= 1 && week <= 2) {
        this.itemsRepeat.push({ label: 'every 2 week', value: 'every 2 week' });
        this.itemsRepeat.push({ label: 'every month', value: 'every month' });
      } else if (hours >= 24 && week >= 1 && week >= 2 && month <= 1) {
        this.itemsRepeat.push({ label: 'every month', value: 'every month' });
      }
    }
    this.dealInput.Reschedule = "No Repeat";
  }
  //validate from
  validateformdeal() {
    if (!this.dealForm.valid || this.data1.image == undefined) {
      return true;
    } else {
      return false;
    }
  }
  //set defult date base on 5 or 10
  public settime() {
    var newdate = new Date();
    var minutes = parseInt(newdate.getMinutes().toString());
    if (minutes >= 11) {
      var minutFirst = parseInt(newdate.getMinutes().toString().substr(0));
      var minutLast = parseInt(newdate.getMinutes().toString().substr(1));
      if (minutLast < 5) {
        var tempm = 5 - minutLast;
        return new Date(newdate.setMinutes(minutes - minutLast));
      } else if (minutLast > 5) {
        var tempm = minutLast - 5;
        return new Date(newdate.setMinutes(minutes - tempm));
      } else {
        return new Date(newdate);
      }
    } else {
      if (minutes < 5) {
        //var tempm = 5 - minutes;
        return new Date(newdate.setMinutes(minutes - minutes));
      } else if (minutes > 5 && minutes != 10) {
        var tempm = minutes - 5;
        return new Date(newdate.setMinutes(minutes - tempm));
      } else {
        return new Date(newdate);
      }
    }
  }
}
