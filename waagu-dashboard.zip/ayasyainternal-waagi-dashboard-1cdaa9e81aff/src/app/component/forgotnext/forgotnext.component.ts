import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { CognitoCallback, LoggedInCallback, DataCallback } from "../../interfaces/interfaces";

import { UserLoginService } from "../../services/cognito.service";
import { ValidationService } from '../../services/validation.service';
import { LoaderService } from '../../services/loader.service';
import { DdbService } from "../../services/ddb.service";
@Component({
  selector: 'app-forgotnext',
  templateUrl: './forgotnext.component.html',
  styleUrls: ['./forgotnext.component.css']
})
export class ForgotnextComponent implements CognitoCallback, OnInit, OnDestroy, DataCallback, LoggedInCallback {
  forgotNextForm: any;
  errorMessage: string;
  email: string;
  private sub: any;
  isResend: boolean;
  constructor(public router: Router, public route: ActivatedRoute,
    public ddb: DdbService,
    public loaderService: LoaderService,
    public userService: UserLoginService,
    private formBuilder: FormBuilder) {
    this.forgotNextForm = this.formBuilder.group({
      'password': ['', [Validators.required]],
      'verificationCode': ['', [Validators.required]]
    });
  }
  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.email = params['email'];
    });
    this.forgotNextForm = this.formBuilder.group({
      'password': ['', [Validators.required]],
      'verificationCode': ['', [Validators.required]]
    });
    this.errorMessage = null;
    this.isResend = false;
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
  onResend() {
    this.loaderService.display(true);
    this.isResend = true;
    this.errorMessage = null;
    this.userService.forgotPassword(this.email, this);
  }
  onNext() {
    this.loaderService.display(true);
    if (this.forgotNextForm.dirty && this.forgotNextForm.valid) {
      this.errorMessage = null;
      this.userService.confirmNewPassword(this.email, this.forgotNextForm.value.verificationCode, this.forgotNextForm.value.password, this);
    }

  }

  cognitoCallback(message: string) {
    if (message != null) {
      this.errorMessage = message;
      this.loaderService.display(false);
    } else {
      this.loaderService.display(false);
      if (this.isResend == true) {
        this.errorMessage = "Code has been sent";
        this.isResend = false;
      } else {
        this.ddb.updateUserPassword(this.email, this.forgotNextForm.value.password, this)

      }
    }
  }
  dataCallback(message: string, result: any) {
    if (message != null) {
      this.errorMessage = message;
      this.loaderService.display(false);
    } else {
      this.router.navigate(['/login']);
      this.loaderService.display(false);
    }
  }
  isLoggedIn(message: string, isLoggedIn: boolean) {
    if (isLoggedIn)
      this.router.navigate(['/dashboard']);
  }

}
