import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotnextComponent } from './forgotnext.component';

describe('ForgotnextComponent', () => {
  let component: ForgotnextComponent;
  let fixture: ComponentFixture<ForgotnextComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForgotnextComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgotnextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
