import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { CognitoCallback, LoggedInCallback, DataCallback } from "../../interfaces/interfaces";
import { UserSession } from '../../models/models';

import { UserLoginService } from "../../services/cognito.service";
import { ValidationService } from '../../services/validation.service';
import { LoaderService } from '../../services/loader.service';
import { DdbService } from "../../services/ddb.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements CognitoCallback, LoggedInCallback, OnInit, DataCallback {
  public userDetails: UserSession = new UserSession;
  loginForm: any;
  errorMessage: any;
  constructor(public router: Router,
    public loaderService: LoaderService,
    public ddb: DdbService,
    public userService: UserLoginService,
    private formBuilder: FormBuilder) {
    this.loginForm = this.formBuilder.group({
      'email': ['', [Validators.required, ValidationService.emailValidator]],
      'password': ['', [Validators.required]]
    });
  }
  ngOnInit() {
    this.userService.isAuthenticated(this);
  }
  onLogin() {

    this.loaderService.display(true);
    if (this.loginForm.dirty && this.loginForm.valid) {

      this.errorMessage = "";
      this.userService.authenticate(this.loginForm.value.email, this.loginForm.value.password, this);
    }
  }

  cognitoCallback(message: string, result: any) {
    if (message != null) {
      if (message == "User is disabled") {
        this.errorMessage = "Your account is not active, please contact our support team";
      } else {
        this.errorMessage = message;
      }
      this.loaderService.display(false);
      if (message === 'User is not confirmed.') {
        this.router.navigate(['/login', this.loginForm.value.email]);
      }
    } else {
      this.ddb.getUserDetails(this.loginForm.value.email, this);
    }
  }
  isLoggedIn(message: string, isLoggedIn: boolean) {
    if (isLoggedIn)
      this.router.navigate(['/dashboard']);
  }
  dataCallback(message: string, result: any) {
    if (message != null) {
    } else {
      var root = this;
      this.router.navigate(['/dashboard']);
    }
  }
}
