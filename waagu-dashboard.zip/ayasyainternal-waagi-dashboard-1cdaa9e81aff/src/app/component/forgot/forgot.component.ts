import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { CognitoCallback, LoggedInCallback } from "../../interfaces/interfaces";

import { UserLoginService } from "../../services/cognito.service";
import { ValidationService } from '../../services/validation.service';
import { LoaderService } from '../../services/loader.service';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent implements CognitoCallback {

  forgotForm: any;
  errorMessage: string;
  constructor(public router: Router,
    public loaderService: LoaderService,
    public userService: UserLoginService,
    private formBuilder: FormBuilder) {
    this.forgotForm = this.formBuilder.group({
      'email': ['', [Validators.required, ValidationService.emailValidator]]
    });
  }

  onNext() {
    this.loaderService.display(true);
    if (this.forgotForm.dirty && this.forgotForm.valid) {
      this.errorMessage = null;
      this.userService.forgotPassword(this.forgotForm.value.email, this);
    }
  }

  cognitoCallback(message: string, result: any) {
    if (message == null && result == null) {
      this.loaderService.display(false);
      this.router.navigate(['/forgot', this.forgotForm.value.email]);
    } else {
      this.loaderService.display(false);
      this.errorMessage = message;
    }
  }
  isLoggedIn(message: string, isLoggedIn: boolean) {
    if (isLoggedIn)
      this.router.navigate(['/dashboard']);
  }

}
