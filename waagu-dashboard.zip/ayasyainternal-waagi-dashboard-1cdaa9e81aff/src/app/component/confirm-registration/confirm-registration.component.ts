import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { CognitoCallback, LoggedInCallback, DataCallback } from '../../interfaces/interfaces';

import { UserLoginService, UserRegistrationService } from "../../services/cognito.service";

import { ValidationService } from '../../services/validation.service';
import { LoaderService } from '../../services/loader.service';
import { DdbService } from "../../services/ddb.service";
@Component({
  selector: 'app-confirm-registration',
  templateUrl: './confirm-registration.component.html',
  styleUrls: ['./confirm-registration.component.css']
})
export class ConfirmRegistrationComponent implements CognitoCallback, OnInit, OnDestroy, LoggedInCallback, DataCallback {

  confrimRegistrationForm: any;
  errorMessage: string;
  email: string;
  private sub: any;
  isResend: boolean;
  constructor(public router: Router, public route: ActivatedRoute,
    public loaderService: LoaderService,
    public userService: UserLoginService,
    public userRegistrationService: UserRegistrationService,
    public ddb: DdbService,
    private formBuilder: FormBuilder) {
    this.confrimRegistrationForm = this.formBuilder.group({
      'email': ['', [Validators.required, ValidationService.emailValidator]],
      'confirmationCode': ['', [Validators.required]]
    });
  }
  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.email = params['email'];
    });
    this.errorMessage = null;
    this.isResend = false;
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
  onResend() {
    this.loaderService.display(true);
    this.isResend = true;
    this.errorMessage = null;
    this.userRegistrationService.resendCode(this.email, this);
  }
  onConfrim() {
    this.isResend = false;
    this.loaderService.display(true);
    if (this.confrimRegistrationForm.dirty && this.confrimRegistrationForm.valid) {
      this.errorMessage = null;
      this.userRegistrationService.confirmRegistration(this.email, this.confrimRegistrationForm.value.confirmationCode, this);
    }

  }
  cognitoCallback(message: string) {
    if (message != null) { //error
      if (message == "Username/client id combination not found.") {
        this.errorMessage = "Username/verification code is incorrect.";
      } else {
        this.errorMessage = message;
      }

      this.loaderService.display(false);
    } else {
      if (this.isResend == true) {
        this.loaderService.display(false);
        this.errorMessage = "Code has been sent";
        this.isResend = false;
      } else {
        var password = localStorage.getItem("userPassword");
        this.userRegistrationService.autoAuthenticate(this.email, password, this);
      }
    }
  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
    if (isLoggedIn) {
      this.ddb.getUserDetails(this.email, this);
    }
  }
  dataCallback(message: string, result: any) {
    if (message != null) {
    } else {
      var root = this;
      localStorage.removeItem("userPassword");
      this.router.navigate(['/dashboard']);
    }
  }
}
