import { Component, OnInit, NgModule, ChangeDetectorRef, ViewChild, NgZone } from '@angular/core';
import { Router } from "@angular/router";
import { ImageCropperComponent, CropperSettings, Bounds } from 'ng2-img-cropper';
import { FormControl } from '@angular/forms';
import { AgmCoreModule, MapsAPILoader } from 'angular2-google-maps/core'
import 'rxjs/add/operator/map';
import 'rxjs/Rx';

import { User, Shopsdropdown } from '../../models/models';
import { LoggedInCallback, DataCallback,DataCallbackStatus } from "../../interfaces/interfaces";

import { UserParametersService, UserLoginService } from "../../services/cognito.service";
import { LoaderService } from '../../services/loader.service';
import { DdbService } from "../../services/ddb.service";

import { AppComponent } from "../../app.component";

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements LoggedInCallback, DataCallback,DataCallbackStatus {
  google: any;
  public users: Array<User> = [];
  public rolebasep = 0;
  public selectedShop: string;
  public companyName: string;
  public emailId: string;
  public editMode: boolean;
  public oldPassword: string;
  public newPassword: string;
  public editPassword: boolean;

  public indexEdit: number;
  public uploadImg: boolean;

  public data1: any;
  public cropperSettings1: CropperSettings;
  public croppedWidth: number;
  public croppedHeight: number;
  public lat: number;
  public lng: number;
  public markers: any;
  public editMapMode: boolean;
  public reloadMapMode: boolean;
  public profile: any;
  public errorMessage: any;
  @ViewChild('cropper', undefined) cropper: ImageCropperComponent;
  public searchControl: FormControl;
  @ViewChild("search")
  public searchElementRef: any;

  constructor(
    public ngZone: NgZone,
    public mapsAPILoader: MapsAPILoader,
    public loaderService: LoaderService,
    private changeDetectorRef: ChangeDetectorRef,
    public router: Router,
    public ddb: DdbService,
    public userService: UserLoginService,
    public userParametersService: UserParametersService,
    public me: AppComponent
  ) {
    this.userService.isAuthenticated(this);
    this.uploadImg = false;
    this.editMapMode = false;
    this.reloadMapMode = false;

    this.cropperSettings1 = new CropperSettings();
    this.cropperSettings1.width = 200;
    this.cropperSettings1.height = 200;

    this.cropperSettings1.croppedWidth = 200;
    this.cropperSettings1.croppedHeight = 200;

    this.cropperSettings1.canvasWidth = 200;
    this.cropperSettings1.canvasHeight = 200;

    this.cropperSettings1.minWidth = 100;
    this.cropperSettings1.minHeight = 100;

    this.cropperSettings1.rounded = false;
    this.cropperSettings1.keepAspect = true;
    this.cropperSettings1.cropperDrawSettings.strokeColor = 'rgba(255,255,255,1)';
    this.cropperSettings1.cropperDrawSettings.strokeWidth = 2;

    this.data1 = {};

  }
  shops = [
    { label: 'Select Shop', value: null },
    { label: 'Dining', value: 'Dining' },
    { label: 'Clothing', value: 'Clothing' },
    { label: 'Electronics', value: 'Electronics' },
    { label: 'Groceries', value: 'Groceries' },
    { label: 'Other Stuff', value: 'Other Stuff' }];

  ngOnInit() {
    this.searchControl = new FormControl();
    this.mapsAPILoader.load().then(() => {
      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ["address"]
      });
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }
          this.markers = [{
            lat: place.geometry.location.lat(),
            lng: place.geometry.location.lng(),
            address: place.formatted_address
          }];
          this.lat = place.geometry.location.lat();
          this.lng = place.geometry.location.lng();
        });
      });
    });
  }


  onChangeStatus(id: string, status: string): void {
    this.ddb.updateUserStatus(id, status);

  }
  onChangeAdminStatus(id: string, status: number): void {
    this.ddb.updateAdminStatus(id, status);
  }
  onEditUpdate() {
    this.editMode = false;
    this.ddb.updateUserDetails(this.companyName, this.emailId, this.selectedShop, this.editPassword, this.oldPassword, this.newPassword, this.uploadImg, this.data1.image);
    setTimeout(() => {
      this.users[this.indexEdit].CompanyName = this.companyName;
      this.users[this.indexEdit].Stuff = this.selectedShop;
      this.users[this.indexEdit].FeatureImage = this.users[this.indexEdit].FeatureImage + "?" + new Date().getTime();
      this.uploadImg = false;
      this.data1 = {};
      this.indexEdit = null;
      this.loaderService.display(false);
    }, 8000);
  }
  onEditPopup(CompanyName: string, EmailId: string, Shop: string, index: number) {
    this.ddb.getUserActiveEntries(this);
    this.editMode = true;
    this.editPassword = false;
    this.uploadImg = false;
    this.oldPassword = "";
    this.newPassword = "";
    this.data1 = {};
    this.selectedShop = Shop;
    this.companyName = CompanyName;
    this.emailId = EmailId;
    this.indexEdit = index;
  }
  onClosePopup() {
    this.editMode = false;
    this.editPassword = false;
    this.uploadImg = false;
    this.data1 = {};
    this.oldPassword = "";
    this.newPassword = "";
    this.selectedShop = null;
    this.companyName = "";
    this.emailId = "";
    this.indexEdit = null;
  }
  onInput($event) {
    $event.preventDefault();
  }
  validateform() {
    if ((this.oldPassword == "" && this.newPassword == "" && this.editPassword == true) || this.companyName == "") {
      return true;
    } else {
      return false;
    }
  }


  onEditMap() {
    this.editMapMode = false;
    this.users[this.indexEdit].Longitude = this.markers[0].lng;
    this.users[this.indexEdit].Latitude = this.markers[0].lat;
    this.users[this.indexEdit].Address = this.markers[0].address;
    this.ddb.updateUserMapDetails(this.emailId, this.markers);
    setTimeout(() => {
      this.markers = [];
      this.emailId = "";
      this.indexEdit = null;
      this.lat = null;
      this.lng = null;
      this.reloadMapMode = false;

    }, 3000);
  }

  onEditMapPopup(EmailId: string, Lat: number, Lng: number, Address: string, index: number) {
    this.ddb.getUserActiveEntries(this);
    this.editMapMode = true;
    this.reloadMapMode = true;
    this.markers = [{
      lat: Lat,
      lng: Lng,
      address: Address
    }];
    this.emailId = EmailId;
    this.indexEdit = index;
    this.lat = Lat;
    this.lng = Lng;
  }

  onCloseMapPopup() {
    this.editMapMode = false;
    this.reloadMapMode = false;
    this.markers = [];
    this.emailId = "";
    this.indexEdit = null;
    this.lat = null;
    this.lng = null;
    this.searchElementRef.nativeElement.value = "";
  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
    this.editMode = false;

    if (!isLoggedIn) {
      this.router.navigate(['/login']);
    } else {
      this.ddb.getUserActiveEntries(this);
      this.rolebasep = this.me.rolebase;
      this.ddb.getUserEntries(this.users);
    }
  }

  changeFetureModel() {
    this.uploadImg == true ? this.uploadImg = false : this.uploadImg = true;
    this.data1 = {};
  }

  cropped(bounds: Bounds) {
    this.croppedHeight = bounds.bottom - bounds.top;
    this.croppedWidth = bounds.right - bounds.left;
  }

  fileChangeListener($event) {
    var image: any = new Image();
    var file: File = $event.target.files[0];
    var myReader: FileReader = new FileReader();
    var that = this;
    myReader.onloadend = function (loadEvent: any) {
      image.src = loadEvent.target.result;
      that.cropper.setImage(image);
    };
    myReader.readAsDataURL(file);
  }
  mapClicked($event: any) {
    this.mapsAPILoader.load().then(() => {
      let geocoder = new google.maps.Geocoder();
      let latLng = new google.maps.LatLng($event.coords.lat, $event.coords.lng);
      geocoder.geocode({ 'location': latLng }, (
        (results: google.maps.GeocoderResult[], status: google.maps.GeocoderStatus) => {
          if (status === google.maps.GeocoderStatus.OK) {
            this.markers = [{
              lat: parseFloat($event.coords.lat.toFixed(7)),
              lng: parseFloat($event.coords.lng.toFixed(7)),
              address: results[0].formatted_address
            }];
          } else {
            this.markers = [{
              lat: parseFloat($event.coords.lat.toFixed(7)),
              lng: parseFloat($event.coords.lng.toFixed(7)),
              address: "not found"
            }];
          }
        })
      );
    });
  }

  dataCallback(message: string, result: any) {
    if (message != null) { 
      
    } else { 
      
    }
  }
  dataCallbackStatus(message: string, result: any) {
        if (message == "0") {

        } else {
            if(result=='false'){
                this.userService.logout();
                this.router.navigate(['/login']);
            }
        }
    }
}
