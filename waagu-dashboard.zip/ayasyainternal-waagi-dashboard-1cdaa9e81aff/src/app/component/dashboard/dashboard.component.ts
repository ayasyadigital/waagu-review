import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

import { LoggedInCallback, Callback,DataCallbackStatus } from '../../interfaces/interfaces';
import { Counts, Parameters, AppData } from '../../models/models';

import { UserLoginService, UserParametersService, UserCognitoService } from "../../services/cognito.service";
import { DdbService } from "../../services/ddb.service";


declare var AWS: any;
@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements LoggedInCallback,DataCallbackStatus {

    public countslist: Counts = new Counts;
    public parameters: Array<Parameters> = [];
    public appdata: Array<AppData> = [];
    public status:string;
    constructor(
        public router: Router, public ddb: DdbService, public userService: UserLoginService, public userParametersService: UserParametersService, public userCognitoService: UserCognitoService) {
        this.userService.isAuthenticated(this);
        this.userParametersService.getParameters(new GetParametersCallback(this));
    }
    isLoggedIn(message: string, isLoggedIn: boolean) {
        this.ddb.getUserActiveEntries(this);       
        this.ddb.gettest();       
        if (!isLoggedIn) {
            this.router.navigate(['/login']);
        } else {

            this.ddb.getDashboardCounts(this.countslist);
        }
    }
    dataCallbackStatus(message: string, result: any) {
        if (message == "0") {
           // console.log(result);

        } else {
            if(result=='false'){
                this.userService.logout();
                this.router.navigate(['/login']);
            }
            //console.log(result);
        }
    }
}

export class GetParametersCallback implements Callback {
    constructor(public me: DashboardComponent) {
    }

    callback() {
    }

    callbackWithParam(result: any) {
        for (let i = 0; i < result.length; i++) {
            let parameter = new Parameters();
            parameter.name = result[i].getName();
            parameter.value = result[i].getValue();
            this.me.parameters.push(parameter);
        }
        let param = new Parameters()
        param.name = "cognito ID";
        param.value = AWS.config.credentials.params.IdentityId;
        this.me.parameters.push(param)
    }
}
