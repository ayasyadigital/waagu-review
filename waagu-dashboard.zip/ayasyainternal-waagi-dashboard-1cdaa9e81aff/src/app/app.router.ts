import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './component/login/login.component';
import { SignupComponent } from './component/signup/signup.component';
import { ConfirmRegistrationComponent } from './component/confirm-registration/confirm-registration.component';
import { ForgotComponent } from './component/forgot/forgot.component';
import { ForgotnextComponent } from './component/forgotnext/forgotnext.component';
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { UsersComponent } from './component/users/users.component';
import { DealsComponent } from './component/deals/deals.component';

export const router: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'signup', component: SignupComponent },
    { path: 'signup/:email', component: ConfirmRegistrationComponent },
    { path: 'forgot', component: ForgotComponent },
    { path: 'forgot/:email', component: ForgotnextComponent },
    { path: 'dashboard', component: DashboardComponent },
    { path: 'users', component: UsersComponent },
    { path: 'deals', component: DealsComponent },
    { path: 'deals/:email', component: DealsComponent }

];

export const routes: ModuleWithProviders = RouterModule.forRoot(router);