export const environment = {
  production: true,
  region: 'eu-west-1',
  identityPoolId: 'eu-west-1:2e15e5b7-ff8d-4d61-9ca7-3abf5a25e34b',
  userPoolId: 'eu-west-1_l8pL6r3dF',
  clientId: '5vcl1s7m0c57t2f5bgtv1a2is3',
  accessKeyId: 'AKIAI36EJFVTR6NHWYGA',
  secretAccessKey: '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',
  ddbTableName: 'waagihub-mobilehub-699695012-WaagiDeals',
  ddbLogTableName: 'waagihub-mobilehub-699695012-WaggiDealHistory',
  ddbUserTableName: 'waagihub-mobilehub-699695012-WaagiUsers',
  ddbSnsTableName: 'waagihub-mobilehub-699695012-WaagiDelasSns',
  ddbWaagiAppTableName: 'waagihub-mobilehub-699695012-WaagiApp',
  ddbSnsCronTableName: 'waagihub-mobilehub-699695012-WaagiSnsCron',
  RoleArn:'arn:aws:iam::370073765025:role/cognitoadmin',
  GroupNameAdmin:'Admin',
  s3bucketName:'waagi-uploads',
  privewImageUrl:'https://waagi-uploads.s3.amazonaws.com/no_preview.jpg'
};
