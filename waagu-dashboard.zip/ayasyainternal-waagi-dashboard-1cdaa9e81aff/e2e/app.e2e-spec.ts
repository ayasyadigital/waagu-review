import { WaagiWebPage } from './app.po';

describe('waagi-web App', () => {
  let page: WaagiWebPage;

  beforeEach(() => {
    page = new WaagiWebPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
